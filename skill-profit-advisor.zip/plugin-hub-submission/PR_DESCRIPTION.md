Add Skill Profit Advisor

Skill Profit Advisor adds a sidebar panel that shows the most profitable money-making method for each non-combat skill at the player's current levels. It also lists the best methods overall and what the next level unlocks.

How it works:

- Rates (items in and out per hour) are a curated table of 82 OSRS Wiki money-making guides.
- Profit is recalculated from RuneLite's own `ItemManager` prices, with the GE tax optional. The plugin makes no network requests of its own.
- It reads only skill levels, world type (free-to-play or members filter) and quest states (to flag unfinished quests).
- No menu entries, no input, no server actions, no reflection, and no combat or PvP information.
- Methods needing combat levels are hidden by default.

Generated-by: Claude (Cowork)
