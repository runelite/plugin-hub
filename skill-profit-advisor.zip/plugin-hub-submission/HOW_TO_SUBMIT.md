# Submitting Skill Profit Advisor to the RuneLite Plugin Hub

The Plugin Hub builds your plugin from a **public GitHub repository at an exact commit**. Submitting takes two pull requests' worth of steps: your own repo first, then a pull request to `runelite/plugin-hub`.

## 1. Test it in-game first

Run `./gradlew run`, log in, and go through the checklist in the README under "What to test in-game". The Hub reviewers expect a plugin that works.

## 2. Put the plugin in its own public GitHub repo

1. Create an empty public repository on GitHub, for example `skill-profit-advisor`. Don't add a README or license; the project already has both.
2. From the `skill-profit-advisor` folder:

   ```
   git init
   git add .
   git commit -m "Skill Profit Advisor 1.0.0"
   git branch -M master
   git remote add origin https://github.com/<your-username>/skill-profit-advisor.git
   git push -u origin master
   ```
3. Copy the full commit hash: `git rev-parse HEAD`.
4. Optional: set `author=` in `runelite-plugin.properties` to your GitHub or in-game name, and commit before step 3.

## 3. Add the manifest to the Plugin Hub

1. Fork https://github.com/runelite/plugin-hub and create a branch, for example `skill-profit-advisor`.
2. Copy the file `plugins/skill-profit-advisor` from this folder into the `plugins/` directory of your fork.
3. Fill in your repository URL and the commit hash from step 2.
4. Commit, push, and open a pull request against `runelite/plugin-hub` `master`. Use `PR_DESCRIPTION.md` as the description.

## 4. Review

- The Hub's CI builds the plugin from your commit. If it fails, fix it in your repo, push, update the `commit=` line in the manifest, and push the branch again.
- A maintainer reviews the plugin against Jagex's third-party client guidelines. This plugin only reads levels, world type, quests and prices, which is the kind of plugin they accept.
- To update the plugin later, push to your repo and open a new Hub PR with the new commit hash.
