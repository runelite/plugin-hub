/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.IntToLongFunction;
import net.runelite.api.Skill;
import net.runelite.api.gameval.ItemID;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class MethodRankerTest
{
	/** Every item worth 100 gp, coins worth 1. */
	private static final IntToLongFunction FLAT = id -> id == ItemID.COINS ? 1 : 100;

	private static Map<Skill, Integer> levels(int all)
	{
		Map<Skill, Integer> m = new EnumMap<>(Skill.class);
		for (Skill s : Skill.values())
		{
			m.put(s, all);
		}
		m.put(Skill.HITPOINTS, Math.max(10, all));
		return m;
	}

	private static MethodRanker.Options opts(boolean members)
	{
		MethodRanker.Options o = new MethodRanker.Options();
		o.members = members;
		return o;
	}

	@Test
	public void dataIsWellFormed()
	{
		List<MoneyMethod> all = MethodData.all();
		assertTrue("at least 60 methods", all.size() >= 60);
		Set<String> titles = new HashSet<>();
		for (MoneyMethod m : all)
		{
			assertTrue("unique title " + m.getTitle(), titles.add(m.getTitle()));
			assertTrue(m.getTitle() + " trains a non-combat skill", MethodRanker.NON_COMBAT.contains(m.getSkill()));
			assertFalse(m.getTitle() + " has outputs", m.getOutputs().isEmpty());
			assertTrue(m.getWikiUrl().startsWith("https://oldschool.runescape.wiki/w/Money_making_guide/"));
			for (ItemAmount item : m.getInputs())
			{
				assertTrue(item.getItemId() > 0 && item.getQuantity() > 0);
			}
			for (ItemAmount item : m.getOutputs())
			{
				assertTrue(item.getItemId() > 0 && item.getQuantity() > 0);
			}
			for (int level : m.getRequirements().values())
			{
				assertTrue(level >= 1 && level <= 99);
			}
		}
	}

	@Test
	public void geTax()
	{
		assertEquals(49, GeTax.afterTax(49));
		assertEquals(49, GeTax.afterTax(50));             // 2% of 50 = 1
		assertEquals(980, GeTax.afterTax(1000));
		assertEquals(1_000_000_000L - 5_000_000, GeTax.afterTax(1_000_000_000L));   // capped
	}

	@Test
	public void profitIsOutputsMinusInputs()
	{
		MoneyMethod steel = find("Smelting steel bars");
		MethodRanker.Recommendation r = MethodRanker.price(steel, FLAT, false, java.util.Collections.emptyList());
		assertEquals(775 * 100 + 1550 * 100, r.inputCost);
		assertEquals(775 * 100, r.outputValue);
		assertEquals(-1550 * 100, r.profit);
	}

	@Test
	public void freeToPlayNeverGetsMembersMethods()
	{
		MethodRanker.Result res = MethodRanker.rank(MethodData.all(), levels(99), realisticPrices(), q -> true, opts(false));
		for (MethodRanker.Recommendation r : res.topOverall)
		{
			assertFalse(r.method.getTitle(), r.method.isMembers());
		}
		for (MethodRanker.SkillAdvice a : res.perSkill)
		{
			if (a.best != null)
			{
				assertFalse(a.best.method.isMembers());
			}
		}
	}

	@Test
	public void levelsGateMethodsAndNextUnlockIsAboveCurrentLevel()
	{
		Map<Skill, Integer> lv = levels(1);
		lv.put(Skill.SMITHING, 40);
		MethodRanker.Result res = MethodRanker.rank(MethodData.all(), lv, realisticPrices(), q -> true, opts(true));
		MethodRanker.SkillAdvice smithing = advice(res, Skill.SMITHING);
		assertNotNull(smithing.best);
		assertTrue(smithing.best.method.getPrimaryLevel() <= 40);
		assertNotNull("something better unlocks later", smithing.nextUnlock);
		assertTrue(smithing.nextUnlock.method.getPrimaryLevel() > 40);
		assertTrue(smithing.nextUnlock.profit > smithing.best.profit);
		for (MethodRanker.Recommendation r : res.topOverall)
		{
			assertTrue(r.method.getTitle(), MethodRanker.meetsAll(r.method, lv));
		}
	}

	@Test
	public void combatRequirementsAreHiddenByDefault()
	{
		MethodRanker.Result res = MethodRanker.rank(MethodData.all(), levels(99), realisticPrices(), q -> true, opts(true));
		for (MethodRanker.SkillAdvice a : res.perSkill)
		{
			if (a.best != null)
			{
				assertFalse(a.best.method.getTitle(), MethodRanker.needsCombat(a.best.method));
			}
		}
		MethodRanker.Options o = opts(true);
		o.allowCombatRequirements = true;
		boolean any = false;
		for (MethodRanker.SkillAdvice a : MethodRanker.rank(MethodData.all(), levels(99), realisticPrices(), q -> true, o).perSkill)
		{
			any |= a.best != null && MethodRanker.needsCombat(a.best.method);
		}
		assertTrue("with the option on, a combat-gated method can win (farming herb runs)", any);
	}

	@Test
	public void unfinishedQuestsAreFlaggedOrHidden()
	{
		MethodRanker.Result shown = MethodRanker.rank(MethodData.all(), levels(99), realisticPrices(), q -> false, opts(true));
		MethodRanker.SkillAdvice smithing = advice(shown, Skill.SMITHING);
		assertNotNull(smithing.best);
		MethodRanker.Options o = opts(true);
		o.requireFinishedQuests = true;
		MethodRanker.Result hidden = MethodRanker.rank(MethodData.all(), levels(99), realisticPrices(), q -> false, o);
		for (MethodRanker.Recommendation r : hidden.topOverall)
		{
			assertTrue(r.method.getTitle(), r.method.getQuests().isEmpty());
		}
	}

	@Test
	public void perRunMethodsNeverRankAgainstHourlyOnes()
	{
		MethodRanker.Result res = MethodRanker.rank(MethodData.all(), levels(99), realisticPrices(), q -> true, opts(true));
		for (MethodRanker.Recommendation r : res.topOverall)
		{
			assertFalse(r.method.isPerRun());
		}
		MethodRanker.SkillAdvice farming = advice(res, Skill.FARMING);
		assertNotNull(farming.best);
		assertTrue(farming.best.method.isPerRun());
	}

	@Test
	public void losingMethodsAreHiddenUnlessAsked()
	{
		IntToLongFunction expensiveInputs = id -> id == ItemID.COINS ? 1 : (id == ItemID.STEEL_BAR ? 10 : 1000);
		Map<Skill, Integer> lv = levels(1);
		lv.put(Skill.SMITHING, 30);
		MethodRanker.Result res = MethodRanker.rank(MethodData.all(), lv, expensiveInputs, q -> true, opts(false));
		assertNull(advice(res, Skill.SMITHING).best);
		MethodRanker.Options o = opts(false);
		o.showUnprofitable = true;
		assertNotNull(advice(MethodRanker.rank(MethodData.all(), lv, expensiveInputs, q -> true, o), Skill.SMITHING).best);
	}

	// ------------------------------------------------------------- helpers

	/** A plausible price sheet: products worth more than their raw inputs. */
	private static IntToLongFunction realisticPrices()
	{
		Map<Integer, Long> p = new HashMap<>();
		p.put(ItemID.IRON_ORE, 100L);
		p.put(ItemID.COAL, 150L);
		p.put(ItemID.STEEL_BAR, 500L);
		p.put(ItemID.MITHRIL_ORE, 150L);
		p.put(ItemID.MITHRIL_BAR, 800L);
		p.put(ItemID.ADAMANTITE_ORE, 1000L);
		p.put(ItemID.ADAMANTITE_BAR, 2500L);
		p.put(ItemID.RUNITE_ORE, 11000L);
		p.put(ItemID.RUNITE_BAR, 13000L);
		p.put(ItemID.MCANNONBALL, 200L);
		p.put(ItemID.UNIDENTIFIED_RANARR, 7000L);
		p.put(ItemID.RANARR_SEED, 30000L);
		return id -> id == ItemID.COINS ? 1 : p.getOrDefault(id, 50L);
	}

	private static MoneyMethod find(String title)
	{
		for (MoneyMethod m : MethodData.all())
		{
			if (m.getTitle().equals(title))
			{
				return m;
			}
		}
		throw new AssertionError(title);
	}

	private static MethodRanker.SkillAdvice advice(MethodRanker.Result res, Skill skill)
	{
		for (MethodRanker.SkillAdvice a : res.perSkill)
		{
			if (a.skill == skill)
			{
				return a;
			}
		}
		throw new AssertionError(skill);
	}
}
