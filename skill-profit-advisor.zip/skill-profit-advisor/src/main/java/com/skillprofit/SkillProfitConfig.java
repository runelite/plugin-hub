/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.Range;

@ConfigGroup(SkillProfitConfig.GROUP)
public interface SkillProfitConfig extends Config
{
	String GROUP = "skillprofitadvisor";

	enum Membership
	{
		DETECT("Detect from world"),
		FREE_TO_PLAY("Free-to-play only"),
		MEMBERS("Members");

		private final String label;

		Membership(String label)
		{
			this.label = label;
		}

		@Override
		public String toString()
		{
			return label;
		}
	}

	@ConfigItem(
		keyName = "membership",
		name = "Methods to show",
		description = "Detect from the world you are on, or always show free-to-play or members methods",
		position = 1
	)
	default Membership membership()
	{
		return Membership.DETECT;
	}

	@ConfigItem(
		keyName = "allowCombatRequirements",
		name = "Allow combat requirements",
		description = "Also show skilling methods that need a combat level (e.g. Magic, Hitpoints or Prayer)",
		position = 2
	)
	default boolean allowCombatRequirements()
	{
		return false;
	}

	@ConfigItem(
		keyName = "requireFinishedQuests",
		name = "Only finished quests",
		description = "Hide methods whose quests you have not finished. Off: they are shown with a note "
			+ "(many methods only need part of a quest)",
		position = 3
	)
	default boolean requireFinishedQuests()
	{
		return false;
	}

	@ConfigItem(
		keyName = "applyGeTax",
		name = "Include GE tax",
		description = "Take the 2% Grand Exchange tax off everything a method sells",
		position = 4
	)
	default boolean applyGeTax()
	{
		return true;
	}

	@ConfigItem(
		keyName = "includeRuns",
		name = "Include farming runs",
		description = "Show farming runs (profit per run, not per hour)",
		position = 5
	)
	default boolean includeRuns()
	{
		return true;
	}

	@ConfigItem(
		keyName = "showUnprofitable",
		name = "Show money-losing methods",
		description = "Also show methods that cost more than they make at current prices",
		position = 6
	)
	default boolean showUnprofitable()
	{
		return false;
	}

	@Range(min = 1, max = 10)
	@ConfigItem(
		keyName = "topCount",
		name = "Best overall count",
		description = "How many methods to list under 'Best for you right now'",
		position = 7
	)
	default int topCount()
	{
		return 5;
	}
}
