/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.IntToLongFunction;
import java.util.function.Predicate;
import net.runelite.api.Quest;
import net.runelite.api.Skill;

/**
 * Picks the most profitable method for each non-combat skill from the player's levels and
 * live prices. Pure logic: it never touches the client, so it can be unit tested.
 */
final class MethodRanker
{
	/**
	 * The non-combat skills, in skills-tab order.
	 */
	static final List<Skill> NON_COMBAT = Collections.unmodifiableList(java.util.Arrays.asList(
		Skill.MINING, Skill.SMITHING, Skill.FISHING, Skill.COOKING, Skill.FIREMAKING, Skill.WOODCUTTING,
		Skill.AGILITY, Skill.HERBLORE, Skill.THIEVING, Skill.CRAFTING, Skill.FLETCHING, Skill.HUNTER,
		Skill.RUNECRAFT, Skill.CONSTRUCTION, Skill.FARMING, Skill.SAILING));

	static final Set<Skill> COMBAT = Collections.unmodifiableSet(EnumSet.of(
		Skill.ATTACK, Skill.STRENGTH, Skill.DEFENCE, Skill.RANGED, Skill.MAGIC, Skill.PRAYER, Skill.HITPOINTS,
		Skill.SLAYER));

	static final class Options
	{
		boolean members;
		boolean allowCombatRequirements;
		boolean requireFinishedQuests;
		boolean applyGeTax = true;
		boolean includeRuns = true;
		boolean showUnprofitable;
		int topCount = 5;
	}

	static final class Recommendation
	{
		final MoneyMethod method;
		final long inputCost;
		final long outputValue;
		final long profit;
		final List<Quest> unfinishedQuests;

		Recommendation(MoneyMethod method, long inputCost, long outputValue, List<Quest> unfinishedQuests)
		{
			this.method = method;
			this.inputCost = inputCost;
			this.outputValue = outputValue;
			this.profit = outputValue - inputCost;
			this.unfinishedQuests = unfinishedQuests;
		}
	}

	static final class SkillAdvice
	{
		final Skill skill;
		final int level;
		/**
		 * The best method available now, or null.
		 */
		final Recommendation best;
		/**
		 * The nearest locked method that would earn more than {@link #best}, or null.
		 */
		final Recommendation nextUnlock;
		/**
		 * False when no method in the table trains this skill at all (e.g. Construction).
		 */
		final boolean hasMethods;

		SkillAdvice(Skill skill, int level, Recommendation best, Recommendation nextUnlock, boolean hasMethods)
		{
			this.skill = skill;
			this.level = level;
			this.best = best;
			this.nextUnlock = nextUnlock;
			this.hasMethods = hasMethods;
		}
	}

	static final class Result
	{
		final List<Recommendation> topOverall;
		final List<SkillAdvice> perSkill;

		Result(List<Recommendation> topOverall, List<SkillAdvice> perSkill)
		{
			this.topOverall = topOverall;
			this.perSkill = perSkill;
		}
	}

	private MethodRanker()
	{
	}

	/**
	 * @param methods   the method table
	 * @param levels    the player's real (unboosted) levels
	 * @param prices    item id to Grand Exchange price
	 * @param questDone whether a quest is finished
	 */
	static Result rank(List<MoneyMethod> methods, Map<Skill, Integer> levels, IntToLongFunction prices,
		Predicate<Quest> questDone, Options options)
	{
		List<Recommendation> available = new ArrayList<>();
		List<Recommendation> locked = new ArrayList<>();

		for (MoneyMethod method : methods)
		{
			if (method.isMembers() && !options.members)
			{
				continue;
			}
			if (!options.allowCombatRequirements && needsCombat(method))
			{
				continue;
			}
			if (method.isPerRun() && !options.includeRuns)
			{
				continue;
			}

			List<Quest> unfinished = new ArrayList<>();
			for (Quest quest : method.getQuests())
			{
				if (!questDone.test(quest))
				{
					unfinished.add(quest);
				}
			}
			if (options.requireFinishedQuests && !unfinished.isEmpty())
			{
				continue;
			}

			Recommendation rec = price(method, prices, options.applyGeTax, unfinished);
			if (rec.profit <= 0 && !options.showUnprofitable)
			{
				continue;
			}

			if (meetsAll(method, levels))
			{
				available.add(rec);
			}
			else if (meetsAllExceptPrimary(method, levels))
			{
				locked.add(rec);
			}
		}

		Comparator<Recommendation> byProfit = Comparator.comparingLong((Recommendation r) -> r.profit).reversed();

		List<Recommendation> top = new ArrayList<>();
		for (Recommendation rec : available)
		{
			if (!rec.method.isPerRun())
			{
				top.add(rec);
			}
		}
		top.sort(byProfit);
		if (top.size() > options.topCount)
		{
			top = new ArrayList<>(top.subList(0, Math.max(0, options.topCount)));
		}

		List<SkillAdvice> perSkill = new ArrayList<>();
		for (Skill skill : NON_COMBAT)
		{
			int level = levels.getOrDefault(skill, 1);
			Recommendation best = bestFor(skill, available, false, byProfit);
			if (best == null)
			{
				best = bestFor(skill, available, true, byProfit);
			}
			Recommendation next = nextUnlock(skill, locked, best);
			boolean hasMethods = false;
			for (MoneyMethod method : methods)
			{
				hasMethods |= method.getSkill() == skill;
			}
			perSkill.add(new SkillAdvice(skill, level, best, next, hasMethods));
		}

		return new Result(top, perSkill);
	}

	static boolean needsCombat(MoneyMethod method)
	{
		for (Skill skill : method.getRequirements().keySet())
		{
			if (COMBAT.contains(skill))
			{
				return true;
			}
		}
		return false;
	}

	static boolean meetsAll(MoneyMethod method, Map<Skill, Integer> levels)
	{
		for (Map.Entry<Skill, Integer> req : method.getRequirements().entrySet())
		{
			if (levels.getOrDefault(req.getKey(), 1) < req.getValue())
			{
				return false;
			}
		}
		return true;
	}

	private static boolean meetsAllExceptPrimary(MoneyMethod method, Map<Skill, Integer> levels)
	{
		for (Map.Entry<Skill, Integer> req : method.getRequirements().entrySet())
		{
			if (req.getKey() != method.getSkill() && levels.getOrDefault(req.getKey(), 1) < req.getValue())
			{
				return false;
			}
		}
		return true;
	}

	static Recommendation price(MoneyMethod method, IntToLongFunction prices, boolean geTax, List<Quest> unfinished)
	{
		double in = 0;
		for (ItemAmount item : method.getInputs())
		{
			in += item.getQuantity() * prices.applyAsLong(item.getItemId());
		}
		double out = 0;
		for (ItemAmount item : method.getOutputs())
		{
			long each = prices.applyAsLong(item.getItemId());
			out += item.getQuantity() * (geTax ? GeTax.afterTax(each) : each);
		}
		return new Recommendation(method, Math.round(in), Math.round(out), unfinished);
	}

	private static Recommendation bestFor(Skill skill, List<Recommendation> recs, boolean perRun,
		Comparator<Recommendation> order)
	{
		Recommendation best = null;
		for (Recommendation rec : recs)
		{
			if (rec.method.getSkill() == skill && rec.method.isPerRun() == perRun
				&& (best == null || order.compare(rec, best) < 0))
			{
				best = rec;
			}
		}
		return best;
	}

	/**
	 * The locked method of this skill with the LOWEST level requirement that would beat the
	 * current best (same per-hour / per-run kind); ties go to the higher profit.
	 */
	private static Recommendation nextUnlock(Skill skill, List<Recommendation> locked, Recommendation best)
	{
		Recommendation next = null;
		for (Recommendation rec : locked)
		{
			if (rec.method.getSkill() != skill)
			{
				continue;
			}
			if (best != null && (rec.method.isPerRun() != best.method.isPerRun() || rec.profit <= best.profit))
			{
				continue;
			}
			if (next == null
				|| rec.method.getPrimaryLevel() < next.method.getPrimaryLevel()
				|| (rec.method.getPrimaryLevel() == next.method.getPrimaryLevel() && rec.profit > next.profit))
			{
				next = rec;
			}
		}
		return next;
	}
}
