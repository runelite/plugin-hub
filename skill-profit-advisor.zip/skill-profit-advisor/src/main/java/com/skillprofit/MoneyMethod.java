/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.util.List;
import java.util.Map;
import net.runelite.api.Quest;
import net.runelite.api.Skill;

/**
 * One money-making method from the OSRS Wiki guides: what it trains, what it needs,
 * and what goes in and comes out per hour (or per run).
 */
final class MoneyMethod
{
	private final String title;
	private final Skill skill;
	private final boolean members;
	private final boolean perRun;
	private final Map<Skill, Integer> requirements;
	private final List<Quest> quests;
	private final List<ItemAmount> inputs;
	private final List<ItemAmount> outputs;
	private final String wikiUrl;
	private final String note;

	MoneyMethod(String title, Skill skill, boolean members, boolean perRun, Map<Skill, Integer> requirements,
		List<Quest> quests, List<ItemAmount> inputs, List<ItemAmount> outputs, String wikiUrl, String note)
	{
		this.title = title;
		this.skill = skill;
		this.members = members;
		this.perRun = perRun;
		this.requirements = requirements;
		this.quests = quests;
		this.inputs = inputs;
		this.outputs = outputs;
		this.wikiUrl = wikiUrl;
		this.note = note;
	}

	String getTitle()
	{
		return title;
	}

	/**
	 * The skill this method trains (the one it is listed under).
	 */
	Skill getSkill()
	{
		return skill;
	}

	boolean isMembers()
	{
		return members;
	}

	/**
	 * True for recurring runs (farming): quantities are per run, not per hour.
	 */
	boolean isPerRun()
	{
		return perRun;
	}

	Map<Skill, Integer> getRequirements()
	{
		return requirements;
	}

	/**
	 * The level needed in the skill this method trains.
	 */
	int getPrimaryLevel()
	{
		Integer level = requirements.get(skill);
		return level == null ? 1 : level;
	}

	List<Quest> getQuests()
	{
		return quests;
	}

	List<ItemAmount> getInputs()
	{
		return inputs;
	}

	List<ItemAmount> getOutputs()
	{
		return outputs;
	}

	String getWikiUrl()
	{
		return wikiUrl;
	}

	String getNote()
	{
		return note;
	}
}
