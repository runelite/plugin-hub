/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.runelite.api.Quest;
import net.runelite.client.ui.ColorScheme;
import net.runelite.client.ui.FontManager;
import net.runelite.client.ui.PluginPanel;
import net.runelite.client.util.LinkBrowser;

/**
 * The sidebar: the best methods for the player right now, then the best method for each
 * non-combat skill and what the next level unlocks. Click a method to open its wiki guide.
 */
class SkillProfitPanel extends PluginPanel
{
	private static final int TEXT_WIDTH = 165;
	private static final String GREEN = "#6ee16e";
	private static final String RED = "#e64646";
	private static final String GREY = "#a5a5a5";
	private static final String ORANGE = "#f0a030";

	private final JPanel content = new JPanel();
	private final JLabel status = new JLabel();

	SkillProfitPanel(Runnable onRefresh)
	{
		setLayout(new BorderLayout(0, 6));
		setBackground(ColorScheme.DARK_GRAY_COLOR);

		JPanel header = new JPanel(new BorderLayout(0, 4));
		header.setBackground(ColorScheme.DARK_GRAY_COLOR);
		JLabel title = new JLabel("Skill Profit Advisor");
		title.setFont(FontManager.getRunescapeBoldFont());
		title.setForeground(Color.WHITE);
		header.add(title, BorderLayout.NORTH);
		status.setFont(FontManager.getRunescapeSmallFont());
		status.setForeground(ColorScheme.LIGHT_GRAY_COLOR);
		header.add(status, BorderLayout.CENTER);
		JButton refresh = new JButton("Refresh");
		refresh.setFocusable(false);
		refresh.addActionListener(e -> onRefresh.run());
		header.add(refresh, BorderLayout.SOUTH);
		add(header, BorderLayout.NORTH);

		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		content.setBackground(ColorScheme.DARK_GRAY_COLOR);
		add(content, BorderLayout.CENTER);

		showMessage("Log in to see advice", "The advisor reads your skill levels when you are logged in.");
	}

	private void setStatus(String text)
	{
		status.setText("<html><body style='width:" + TEXT_WIDTH + "px'>" + escape(text) + "</body></html>");
	}

	void showMessage(String headline, String detail)
	{
		setStatus(headline);
		content.removeAll();
		content.add(card("<span style='color:" + GREY + "'>" + escape(detail) + "</span>", null, null));
		content.revalidate();
		content.repaint();
	}

	void showResult(MethodRanker.Result result, String statusText)
	{
		setStatus(statusText);
		content.removeAll();

		section("Best for you right now");
		if (result.topOverall.isEmpty())
		{
			content.add(card("<span style='color:" + GREY + "'>No profitable method found for your levels "
				+ "with the current filters.</span>", null, null));
		}
		int rank = 1;
		for (MethodRanker.Recommendation rec : result.topOverall)
		{
			String html = "<b>" + rank++ + ". " + escape(rec.method.getTitle()) + "</b><br>"
				+ "<span style='color:" + GREY + "'>" + rec.method.getSkill().getName() + "</span> &nbsp;"
				+ profit(rec) + quests(rec.unfinishedQuests);
			content.add(card(html, rec.method.getWikiUrl(), tooltip(rec)));
		}

		section("By skill");
		for (MethodRanker.SkillAdvice advice : result.perSkill)
		{
			StringBuilder html = new StringBuilder();
			html.append("<b>").append(advice.skill.getName()).append("</b> <span style='color:").append(GREY)
				.append("'>level ").append(advice.level).append("</span><br>");
			String url = null;
			String tip = null;
			if (advice.best != null)
			{
				html.append(escape(advice.best.method.getTitle())).append("<br>").append(profit(advice.best))
					.append(quests(advice.best.unfinishedQuests));
				url = advice.best.method.getWikiUrl();
				tip = tooltip(advice.best);
			}
			else
			{
				html.append("<span style='color:").append(GREY).append("'>")
					.append(advice.hasMethods ? "No profitable method yet" : "No money-making guide trains this skill")
					.append("</span>");
			}
			if (advice.nextUnlock != null)
			{
				MoneyMethod next = advice.nextUnlock.method;
				html.append("<br><span style='color:").append(GREY).append("'>Next: ").append(escape(next.getTitle()))
					.append(" at ").append(next.getPrimaryLevel()).append(" (")
					.append(Format.gp(advice.nextUnlock.profit)).append(next.isPerRun() ? "/run" : "/hr")
					.append(")</span>");
			}
			content.add(card(html.toString(), url, tip));
		}

		content.add(card("<span style='color:" + GREY + "'>Rates are the OSRS Wiki money-making guides' "
			+ "per-hour figures, priced at live GE prices. Real rates depend on gear, quests, diaries and "
			+ "buy limits. Hover a method for details; click it to open the guide.</span>", null, null));

		content.revalidate();
		content.repaint();
	}

	private void section(String name)
	{
		JLabel label = new JLabel(name);
		label.setFont(FontManager.getRunescapeBoldFont());
		label.setForeground(ColorScheme.BRAND_ORANGE);
		label.setBorder(new EmptyBorder(8, 2, 4, 2));
		JPanel row = new JPanel(new BorderLayout());
		row.setBackground(ColorScheme.DARK_GRAY_COLOR);
		row.add(label, BorderLayout.WEST);
		content.add(row);
	}

	private JPanel card(String html, String url, String tooltip)
	{
		JPanel card = new JPanel(new BorderLayout());
		card.setBackground(ColorScheme.DARKER_GRAY_COLOR);
		card.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createMatteBorder(0, 0, 4, 0, ColorScheme.DARK_GRAY_COLOR),
			new EmptyBorder(6, 8, 6, 8)));
		JLabel label = new JLabel("<html><body style='width:" + TEXT_WIDTH + "px'>" + html + "</body></html>");
		label.setFont(FontManager.getRunescapeSmallFont());
		label.setForeground(ColorScheme.TEXT_COLOR);
		card.add(label, BorderLayout.CENTER);
		if (tooltip != null)
		{
			label.setToolTipText(tooltip);
		}
		if (url != null)
		{
			card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			MouseAdapter click = new MouseAdapter()
			{
				@Override
				public void mouseClicked(MouseEvent e)
				{
					LinkBrowser.browse(url);
				}

				@Override
				public void mouseEntered(MouseEvent e)
				{
					card.setBackground(ColorScheme.DARKER_GRAY_HOVER_COLOR);
				}

				@Override
				public void mouseExited(MouseEvent e)
				{
					card.setBackground(ColorScheme.DARKER_GRAY_COLOR);
				}
			};
			card.addMouseListener(click);
			label.addMouseListener(click);
		}
		return card;
	}

	private static String profit(MethodRanker.Recommendation rec)
	{
		String colour = rec.profit >= 0 ? GREEN : RED;
		return "<span style='color:" + colour + "'>" + Format.gp(rec.profit) + (rec.method.isPerRun() ? " gp/run" : " gp/hr")
			+ "</span>";
	}

	private static String quests(List<Quest> unfinished)
	{
		if (unfinished == null || unfinished.isEmpty())
		{
			return "";
		}
		StringBuilder sb = new StringBuilder("<br><span style='color:" + ORANGE + "'>Needs: ");
		for (int i = 0; i < unfinished.size(); i++)
		{
			sb.append(i > 0 ? ", " : "").append(escape(unfinished.get(i).getName()));
		}
		return sb.append("</span>").toString();
	}

	private static String tooltip(MethodRanker.Recommendation rec)
	{
		MoneyMethod m = rec.method;
		String per = m.isPerRun() ? "run" : "hour";
		StringBuilder sb = new StringBuilder("<html><b>").append(escape(m.getTitle())).append("</b><br>");
		sb.append("Requires: ");
		boolean first = true;
		for (java.util.Map.Entry<net.runelite.api.Skill, Integer> req : m.getRequirements().entrySet())
		{
			sb.append(first ? "" : ", ").append(req.getKey().getName()).append(' ').append(req.getValue());
			first = false;
		}
		sb.append(m.isMembers() ? " (members)" : " (free-to-play)").append("<br>");
		if (!m.getInputs().isEmpty())
		{
			sb.append("<br>Uses per ").append(per).append(':');
			for (ItemAmount item : m.getInputs())
			{
				sb.append("<br>&nbsp; ").append(Format.qty(item.getQuantity())).append(" x ").append(escape(item.getName()));
			}
		}
		sb.append("<br>Makes per ").append(per).append(':');
		for (ItemAmount item : m.getOutputs())
		{
			sb.append("<br>&nbsp; ").append(Format.qty(item.getQuantity())).append(" x ").append(escape(item.getName()));
		}
		sb.append("<br><br>Cost ").append(Format.gp(rec.inputCost)).append(" &middot; Value ")
			.append(Format.gp(rec.outputValue)).append(" &middot; Profit ").append(Format.gp(rec.profit));
		if (!m.getNote().isEmpty())
		{
			sb.append("<br><i>").append(escape(m.getNote())).append("</i>");
		}
		return sb.append("<br>Click to open the wiki guide.</html>").toString();
	}

	static String escape(String s)
	{
		return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
	}
}
