/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import com.google.inject.Provides;
import java.awt.image.BufferedImage;
import java.util.EnumMap;
import java.util.Map;
import javax.inject.Inject;
import javax.swing.SwingUtilities;
import net.runelite.api.Client;
import net.runelite.api.GameState;
import net.runelite.api.Quest;
import net.runelite.api.QuestState;
import net.runelite.api.Skill;
import net.runelite.api.WorldType;
import net.runelite.api.events.GameStateChanged;
import net.runelite.api.events.GameTick;
import net.runelite.api.events.StatChanged;
import net.runelite.api.events.WorldChanged;
import net.runelite.api.gameval.ItemID;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.events.ConfigChanged;
import net.runelite.client.game.ItemManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.ClientToolbar;
import net.runelite.client.ui.NavigationButton;
import net.runelite.client.util.ImageUtil;

/**
 * Tells the player the most profitable thing to train in each non-combat skill at their
 * current levels, priced at live Grand Exchange prices.
 *
 * It only READS: skill levels, the world type, quest states and item prices. It sends
 * nothing to the server, adds no menu entries and makes no network requests of its own
 * (prices come from RuneLite's own ItemManager).
 */
@PluginDescriptor(
	name = "Skill Profit Advisor",
	description = "Shows the most profitable non-combat skilling method for your levels, at live GE prices",
	tags = {"money", "making", "profit", "gp", "skilling", "skills", "grand exchange", "advisor"}
)
public class SkillProfitPlugin extends Plugin
{
	/**
	 * Ticks between retries while RuneLite is still loading prices.
	 */
	private static final int PRICE_RETRY_TICKS = 10;

	@Inject
	private Client client;

	@Inject
	private ClientThread clientThread;

	@Inject
	private ItemManager itemManager;

	@Inject
	private ClientToolbar clientToolbar;

	@Inject
	private SkillProfitConfig config;

	private SkillProfitPanel panel;
	private NavigationButton navButton;

	private final Map<Skill, Integer> lastLevels = new EnumMap<>(Skill.class);
	private boolean dirty;
	private boolean pricesPending;
	private int retryTicks;

	@Override
	protected void startUp()
	{
		panel = new SkillProfitPanel(this::requestRefresh);
		BufferedImage icon = ImageUtil.loadImageResource(SkillProfitPlugin.class, "icon.png");
		navButton = NavigationButton.builder()
			.tooltip("Skill Profit Advisor")
			.icon(icon)
			.priority(8)
			.panel(panel)
			.build();
		clientToolbar.addNavigation(navButton);
		requestRefresh();
	}

	@Override
	protected void shutDown()
	{
		clientToolbar.removeNavigation(navButton);
		navButton = null;
		panel = null;
		lastLevels.clear();
		dirty = false;
		pricesPending = false;
	}

	@Provides
	SkillProfitConfig provideConfig(ConfigManager configManager)
	{
		return configManager.getConfig(SkillProfitConfig.class);
	}

	private void requestRefresh()
	{
		clientThread.invokeLater(this::refresh);
	}

	@Subscribe
	public void onGameStateChanged(GameStateChanged event)
	{
		if (event.getGameState() == GameState.LOGGED_IN)
		{
			dirty = true;
		}
		else if (event.getGameState() == GameState.LOGIN_SCREEN)
		{
			lastLevels.clear();
			requestRefresh();
		}
	}

	@Subscribe
	public void onStatChanged(StatChanged event)
	{
		// StatChanged fires on every xp drop; only a new LEVEL changes the advice
		Integer previous = lastLevels.put(event.getSkill(), event.getLevel());
		if (previous == null || previous != event.getLevel())
		{
			dirty = true;
		}
	}

	@Subscribe
	public void onWorldChanged(WorldChanged event)
	{
		dirty = true;
	}

	@Subscribe
	public void onConfigChanged(ConfigChanged event)
	{
		if (SkillProfitConfig.GROUP.equals(event.getGroup()))
		{
			requestRefresh();
		}
	}

	@Subscribe
	public void onGameTick(GameTick tick)
	{
		// batch the burst of StatChanged events at login into one refresh
		if (dirty)
		{
			dirty = false;
			refresh();
		}
		else if (pricesPending && ++retryTicks >= PRICE_RETRY_TICKS)
		{
			refresh();
		}
	}

	/**
	 * Runs on the client thread: item compositions (used for price lookups) and quest states
	 * must be read there.
	 */
	private void refresh()
	{
		final SkillProfitPanel target = panel;
		if (target == null)
		{
			return;
		}
		if (client.getGameState() != GameState.LOGGED_IN)
		{
			SwingUtilities.invokeLater(() -> target.showMessage("Log in to see advice",
				"The advisor reads your skill levels when you are logged in."));
			return;
		}

		retryTicks = 0;
		pricesPending = itemManager.getItemPrice(ItemID.IRON_ORE) <= 0;
		if (pricesPending)
		{
			SwingUtilities.invokeLater(() -> target.showMessage("Loading prices...",
				"Waiting for RuneLite to load Grand Exchange prices."));
			return;
		}

		Map<Skill, Integer> levels = new EnumMap<>(Skill.class);
		for (Skill skill : Skill.values())
		{
			levels.put(skill, client.getRealSkillLevel(skill));
		}

		boolean members;
		switch (config.membership())
		{
			case FREE_TO_PLAY:
				members = false;
				break;
			case MEMBERS:
				members = true;
				break;
			default:
				members = client.getWorldType().contains(WorldType.MEMBERS);
				break;
		}

		MethodRanker.Options options = new MethodRanker.Options();
		options.members = members;
		options.allowCombatRequirements = config.allowCombatRequirements();
		options.requireFinishedQuests = config.requireFinishedQuests();
		options.applyGeTax = config.applyGeTax();
		options.includeRuns = config.includeRuns();
		options.showUnprofitable = config.showUnprofitable();
		options.topCount = config.topCount();

		Map<Quest, Boolean> questCache = new EnumMap<>(Quest.class);
		MethodRanker.Result result = MethodRanker.rank(
			MethodData.all(),
			levels,
			itemManager::getItemPrice,
			quest -> questCache.computeIfAbsent(quest, q -> q.getState(client) == QuestState.FINISHED),
			options);

		String statusText = (members ? "Members" : "Free-to-play") + " methods, live GE prices"
			+ (options.applyGeTax ? " after tax" : "");
		SwingUtilities.invokeLater(() -> target.showResult(result, statusText));
	}
}
