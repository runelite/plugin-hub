/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.runelite.api.Quest;
import net.runelite.api.Skill;
import net.runelite.api.gameval.ItemID;

/**
 * The method table, GENERATED from the OSRS Wiki money-making guides (fetched 2026-10-07)
 * by gen_data.py. Quantities are per hour (per run for farming runs), exactly as on each
 * guide; profit is never stored here, it is recalculated from live Grand Exchange prices.
 */
final class MethodData
{
	private static final List<MoneyMethod> METHODS = new ArrayList<>();

	static
	{
		add(new MoneyMethod(
			"Mining iron ore", Skill.MINING, true, false,
			reqs(Skill.MINING, 15),
			quests(),
			list(),
			list(
				item(ItemID.IRON_ORE, "Iron ore", 1700),
				item(ItemID.UNCUT_SAPPHIRE, "Uncut sapphire", 6.61),
				item(ItemID.UNCUT_EMERALD, "Uncut emerald", 3.31),
				item(ItemID.UNCUT_RUBY, "Uncut ruby", 1.66),
				item(ItemID.UNCUT_DIAMOND, "Uncut diamond", 0.41)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_iron_ore",
			"Rates assume the Mining Guild (60+)."));
		add(new MoneyMethod(
			"Mining coal", Skill.MINING, true, false,
			reqs(Skill.MINING, 30),
			quests(),
			list(),
			list(
				item(ItemID.COAL, "Coal", 350)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_coal",
			"60+ (Mining Guild) recommended."));
		add(new MoneyMethod(
			"Mining gold ore", Skill.MINING, true, false,
			reqs(Skill.MINING, 40),
			quests(),
			list(),
			list(
				item(ItemID.GOLD_ORE, "Gold ore", 500)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_gold_ore",
			""));
		add(new MoneyMethod(
			"Mining basalt", Skill.MINING, true, false,
			reqs(Skill.MINING, 72),
			quests(Quest.MAKING_FRIENDS_WITH_MY_ARM),
			list(),
			list(
				item(ItemID.BASALT, "Basalt", 700)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_basalt",
			""));
		add(new MoneyMethod(
			"Mining runite ore", Skill.MINING, true, false,
			reqs(Skill.MINING, 85),
			quests(),
			list(),
			list(
				item(ItemID.RUNITE_ORE, "Runite ore", 65)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_runite_ore",
			"World-hopping between rocks."));
		add(new MoneyMethod(
			"Mining amethyst", Skill.MINING, true, false,
			reqs(Skill.MINING, 92),
			quests(),
			list(),
			list(
				item(ItemID.AMETHYST, "Amethyst", 90)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_amethyst",
			""));
		add(new MoneyMethod(
			"Mining lead ore (Deepfin mine)", Skill.MINING, true, false,
			reqs(Skill.MINING, 25, Skill.SAILING, 67, Skill.CONSTRUCTION, 70),
			quests(Quest.PANDEMONIUM),
			list(),
			list(
				item(ItemID.LEAD_ORE, "Lead ore", 1800),
				item(ItemID.UNCUT_SAPPHIRE, "Uncut sapphire", 7),
				item(ItemID.UNCUT_EMERALD, "Uncut emerald", 3.5),
				item(ItemID.UNCUT_RUBY, "Uncut ruby", 1.75),
				item(ItemID.UNCUT_DIAMOND, "Uncut diamond", 0.44)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Mining_lead_ore_(Deepfin_mine)",
			"Construction 70 to build the bank chest."));
		add(new MoneyMethod(
			"Cutting teak logs", Skill.WOODCUTTING, true, false,
			reqs(Skill.WOODCUTTING, 35),
			quests(),
			list(
				item(ItemID.RING_OF_DUELING_8, "Ring of dueling(8)", 3)),
			list(
				item(ItemID.TEAK_LOGS, "Teak logs", 550)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_teak_logs",
			""));
		add(new MoneyMethod(
			"Cutting mahogany logs", Skill.WOODCUTTING, true, false,
			reqs(Skill.WOODCUTTING, 50),
			quests(Quest.MONKEY_MADNESS_I),
			list(
				item(ItemID.RING_OF_DUELING_8, "Ring of dueling(8)", 1.62)),
			list(
				item(ItemID.MAHOGANY_LOGS, "Mahogany logs", 350)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_mahogany_logs",
			"Only part of Monkey Madness I is needed."));
		add(new MoneyMethod(
			"Cutting yew logs", Skill.WOODCUTTING, true, false,
			reqs(Skill.WOODCUTTING, 60),
			quests(),
			list(
				item(ItemID.FORESTRY_SECATEURS_ATTACHMENT, "Secateurs attachment", 52.5)),
			list(
				item(ItemID.YEW_LOGS, "Yew logs", 210),
				item(ItemID.LEAVES_YEW, "Yew leaves", 105)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_yew_logs",
			"Forestry method (Forestry kit). Anima-infused bark is untradeable and not counted."));
		add(new MoneyMethod(
			"Cutting magic logs", Skill.WOODCUTTING, true, false,
			reqs(Skill.WOODCUTTING, 75),
			quests(),
			list(
				item(ItemID.FORESTRY_SECATEURS_ATTACHMENT, "Secateurs attachment", 32.5)),
			list(
				item(ItemID.MAGIC_LOGS, "Magic logs", 130),
				item(ItemID.LEAVES_MAGIC, "Magic leaves", 65)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_magic_logs",
			""));
		add(new MoneyMethod(
			"Cutting redwood logs", Skill.WOODCUTTING, true, false,
			reqs(Skill.WOODCUTTING, 90),
			quests(),
			list(),
			list(
				item(ItemID.REDWOOD_LOGS, "Redwood logs", 180)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_redwood_logs",
			"Bird nests not counted."));
		add(new MoneyMethod(
			"Catching snowy knights", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 35),
			quests(Quest.FAIRYTALE_II__CURE_A_QUEEN),
			list(
				item(ItemID.BUTTERFLY_JAR, "Butterfly jar", 504),
				item(ItemID.RING_OF_DUELING_8, "Ring of dueling(8)", 2.25)),
			list(
				item(ItemID.BUTTERFLY_JAR_SNOWY, "Snowy knight", 504)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_snowy_knights",
			"Fairy rings (part of Fairytale II)."));
		add(new MoneyMethod(
			"Hunting chinchompas", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 53),
			quests(Quest.EAGLES_PEAK),
			list(),
			list(
				item(ItemID.CHINCHOMPA_CAPTURED, "Chinchompa", 225)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Hunting_chinchompas",
			""));
		add(new MoneyMethod(
			"Hunting pyre foxes", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 57),
			quests(Quest.CHILDREN_OF_THE_SUN),
			list(
				item(ItemID.RING_OF_DUELING_8, "Ring of dueling(8)", 1.46),
				item(ItemID.HUNTING_JERBOA_TAIL, "Jerboa tail", 350)),
			list(
				item(ItemID.HUNTING_FENNECFOX_FUR, "Fox fur", 350),
				item(ItemID.HUNTING_FENNECFOX_MEAT, "Raw pyre fox", 350)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Hunting_pyre_foxes",
			""));
		add(new MoneyMethod(
			"Hunting carnivorous chinchompas", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 63),
			quests(Quest.EAGLES_PEAK),
			list(),
			list(
				item(ItemID.CHINCHOMPA_BIG_CAPTURED, "Red chinchompa", 475)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Hunting_carnivorous_chinchompas",
			"80+ strongly recommended."));
		add(new MoneyMethod(
			"Hunting sunlight antelopes", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 72, Skill.FLETCHING, 62),
			quests(Quest.CHILDREN_OF_THE_SUN),
			list(
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 2.75)),
			list(
				item(ItemID.SUNLIGHT_ANTELOPE_BOLT, "Sunlight antler bolts", 2640),
				item(ItemID.HUNTING_ANTELOPESUN_FUR, "Sunlight antelope fur", 220),
				item(ItemID.HUNTING_ANTELOPESUN_MEAT, "Raw sunlight antelope", 220)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Hunting_sunlight_antelopes",
			""));
		add(new MoneyMethod(
			"Hunting black chinchompas", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 80),
			quests(Quest.EAGLES_PEAK),
			list(
				item(ItemID.STEEL_DART, "Steel dart", 37.5)),
			list(
				item(ItemID.CHINCHOMPA_BLACK, "Black chinchompa", 300)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Hunting_black_chinchompas",
			"Wilderness: player-killer risk."));
		add(new MoneyMethod(
			"Hunting herbiboars", Skill.HUNTER, true, false,
			reqs(Skill.HUNTER, 80, Skill.HERBLORE, 31, Skill.AGILITY, 60),
			quests(Quest.BONE_VOYAGE),
			list(
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 7.5)),
			list(
				item(ItemID.UNIDENTIFIED_GUAM, "Grimy guam leaf", 34.5),
				item(ItemID.UNIDENTIFIED_RANARR, "Grimy ranarr weed", 14.76),
				item(ItemID.UNIDENTIFIED_IRIT, "Grimy irit leaf", 13.26),
				item(ItemID.UNIDENTIFIED_AVANTOE, "Grimy avantoe", 14.94),
				item(ItemID.UNIDENTIFIED_KWUARM, "Grimy kwuarm", 19.62),
				item(ItemID.UNIDENTIFIED_SNAPDRAGON, "Grimy snapdragon", 12.42),
				item(ItemID.UNIDENTIFIED_CADANTINE, "Grimy cadantine", 20.46),
				item(ItemID.UNIDENTIFIED_LANTADYME, "Grimy lantadyme", 19.62),
				item(ItemID.UNIDENTIFIED_DWARF_WEED, "Grimy dwarf weed", 16.86),
				item(ItemID.UNIDENTIFIED_TORSTOL, "Grimy torstol", 13.56),
				item(ItemID.FOSSIL_NUMULITE, "Numulite", 802)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Hunting_herbiboars",
			""));
		add(new MoneyMethod(
			"Climbing the Agility Pyramid", Skill.AGILITY, true, false,
			reqs(Skill.AGILITY, 30, Skill.HITPOINTS, 20),
			quests(),
			list(),
			list(
				item(ItemID.COINS, "Coins", 200000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Climbing_the_Agility_Pyramid",
			"Pyramid tops sold to Simon Templeton."));
		add(new MoneyMethod(
			"Wilderness Agility Course", Skill.AGILITY, true, false,
			reqs(Skill.AGILITY, 52),
			quests(),
			list(
				item(ItemID.COINS, "Coins", 150000)),
			list(
				item(ItemID.RUNE_KITESHIELD, "Rune kiteshield", 24.9),
				item(ItemID.RUNE_CHAINBODY, "Rune chainbody", 24.9),
				item(ItemID.BLIGHTED_4DOSE2RESTORE, "Blighted super restore(4)", 118),
				item(ItemID.BLIGHTED_ANGLERFISH, "Blighted anglerfish", 390),
				item(ItemID.BLIGHTED_MANTARAY, "Blighted manta ray", 390),
				item(ItemID.BLIGHTED_KARAMBWAN, "Blighted karambwan", 390),
				item(ItemID.RUNE_MED_HELM, "Rune med helm", 8.3),
				item(ItemID.ADAMANT_PLATEBODY, "Adamant platebody", 8.3),
				item(ItemID.ADAMANT_PLATELEGS, "Adamant platelegs", 4.15),
				item(ItemID.ADAMANT_FULL_HELM, "Adamant full helm", 4.15),
				item(ItemID.MITHRIL_PLATESKIRT, "Mithril plateskirt", 4.15),
				item(ItemID.MITHRIL_PLATELEGS, "Mithril platelegs", 4.15)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Wilderness_Agility_Course",
			"Wilderness: player-killer risk. Average dispenser rewards."));
		add(new MoneyMethod(
			"Catching shrimp & anchovies", Skill.FISHING, false, false,
			reqs(Skill.FISHING, 15),
			quests(),
			list(),
			list(
				item(ItemID.RAW_ANCHOVIES, "Raw anchovies", 248),
				item(ItemID.RAW_SHRIMP, "Raw shrimps", 372)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_shrimp_%26_anchovies",
			""));
		add(new MoneyMethod(
			"Catching sardines & herring", Skill.FISHING, false, false,
			reqs(Skill.FISHING, 10),
			quests(),
			list(
				item(ItemID.FISHING_BAIT, "Fishing bait", 494)),
			list(
				item(ItemID.RAW_SARDINE, "Raw sardine", 262),
				item(ItemID.RAW_HERRING, "Raw herring", 232)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_sardines_%26_herring",
			""));
		add(new MoneyMethod(
			"Catching lobsters", Skill.FISHING, false, false,
			reqs(Skill.FISHING, 40),
			quests(),
			list(
				item(ItemID.COINS, "Coins", 493)),
			list(
				item(ItemID.RAW_LOBSTER, "Raw lobster", 222)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_lobsters",
			""));
		add(new MoneyMethod(
			"Catching monkfish", Skill.FISHING, true, false,
			reqs(Skill.FISHING, 62),
			quests(Quest.SWAN_SONG),
			list(),
			list(
				item(ItemID.RAW_MONKFISH, "Raw monkfish", 290)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_monkfish",
			""));
		add(new MoneyMethod(
			"Catching sharks", Skill.FISHING, true, false,
			reqs(Skill.FISHING, 76),
			quests(),
			list(),
			list(
				item(ItemID.RAW_SHARK, "Raw shark", 160)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_sharks",
			""));
		add(new MoneyMethod(
			"Catching minnows", Skill.FISHING, true, false,
			reqs(Skill.FISHING, 82),
			quests(Quest.FISHING_CONTEST),
			list(),
			list(
				item(ItemID.RAW_SHARK, "Raw shark", 375)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_minnows",
			"Minnows traded for raw sharks. Needs the full Angler's outfit."));
		add(new MoneyMethod(
			"Catching anglerfish", Skill.FISHING, true, false,
			reqs(Skill.FISHING, 82),
			quests(),
			list(
				item(ItemID.PISCARILIUS_SANDWORMS, "Sandworms", 150)),
			list(
				item(ItemID.RAW_ANGLERFISH, "Raw anglerfish", 150)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_anglerfish",
			""));
		add(new MoneyMethod(
			"Catching dark crabs", Skill.FISHING, true, false,
			reqs(Skill.FISHING, 85),
			quests(),
			list(
				item(ItemID.WILDERNESS_FISHING_BAIT, "Dark fishing bait", 308),
				item(ItemID.COINS, "Coins", 15400)),
			list(
				item(ItemID.RAW_DARK_CRAB, "Raw dark crab", 308)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Catching_dark_crabs",
			"Wilderness: player-killer risk."));
		add(new MoneyMethod(
			"Cooking raw anchovies", Skill.COOKING, false, false,
			reqs(Skill.COOKING, 1),
			quests(),
			list(
				item(ItemID.RAW_ANCHOVIES, "Raw anchovies", 1300)),
			list(
				item(ItemID.ANCHOVIES, "Anchovies", 1300)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cooking_raw_anchovies",
			""));
		add(new MoneyMethod(
			"Cooking plain pizzas", Skill.COOKING, false, false,
			reqs(Skill.COOKING, 35),
			quests(),
			list(
				item(ItemID.PIZZA_BASE, "Pizza base", 540),
				item(ItemID.TOMATO, "Tomato", 540),
				item(ItemID.CHEESE, "Cheese", 540)),
			list(
				item(ItemID.PLAIN_PIZZA, "Plain pizza", 540)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cooking_plain_pizzas",
			""));
		add(new MoneyMethod(
			"Making raw admiral pies", Skill.COOKING, true, false,
			reqs(Skill.COOKING, 70),
			quests(),
			list(
				item(ItemID.PIE_SHELL, "Pie shell", 840),
				item(ItemID.SALMON, "Salmon", 840),
				item(ItemID.TUNA, "Tuna", 840),
				item(ItemID.POTATO, "Potato", 840)),
			list(
				item(ItemID.UNCOOKED_ADMIRAL_PIE, "Raw admiral pie", 840)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_raw_admiral_pies",
			"Thin market: slow to sell."));
		add(new MoneyMethod(
			"Making raw wild pies", Skill.COOKING, true, false,
			reqs(Skill.COOKING, 85),
			quests(),
			list(
				item(ItemID.PIE_SHELL, "Pie shell", 740),
				item(ItemID.RAW_BEAR_MEAT, "Raw bear meat", 740),
				item(ItemID.RAW_RABBIT, "Raw rabbit", 740),
				item(ItemID.RAW_CHOMPY, "Raw chompy", 740)),
			list(
				item(ItemID.UNCOOKED_WILD_PIE, "Raw wild pie", 740)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_raw_wild_pies",
			""));
		add(new MoneyMethod(
			"Cutting raw yellowfin", Skill.COOKING, true, false,
			reqs(Skill.COOKING, 1),
			quests(),
			list(
				item(ItemID.RAW_YELLOWFIN, "Raw yellowfin", 11000)),
			list(
				item(ItemID.SAILING_FINE_FISH_OFFCUTS, "Fine fish offcuts", 11000),
				item(ItemID.YELLOW_FIN, "Yellow fin", 33000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_raw_yellowfin",
			"Sailing content. Low daily volume."));
		add(new MoneyMethod(
			"Cutting raw marlin", Skill.COOKING, true, false,
			reqs(Skill.COOKING, 90),
			quests(),
			list(
				item(ItemID.RAW_MARLIN, "Raw marlin", 11000)),
			list(
				item(ItemID.SAILING_FINE_FISH_OFFCUTS, "Fine fish offcuts", 11000),
				item(ItemID.MARLIN_SCALES, "Marlin scales", 33000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cutting_raw_marlin",
			"Sailing content. Low daily volume."));
		add(new MoneyMethod(
			"Smelting iron bars", Skill.SMITHING, false, false,
			reqs(Skill.SMITHING, 15),
			quests(),
			list(
				item(ItemID.IRON_ORE, "Iron ore", 980),
				item(ItemID.RING_OF_FORGING, "Ring of forging", 7)),
			list(
				item(ItemID.IRON_BAR, "Iron bar", 980)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smelting_iron_bars",
			"Ring of forging is a members item."));
		add(new MoneyMethod(
			"Smelting steel bars", Skill.SMITHING, false, false,
			reqs(Skill.SMITHING, 30),
			quests(),
			list(
				item(ItemID.IRON_ORE, "Iron ore", 775),
				item(ItemID.COAL, "Coal", 1550)),
			list(
				item(ItemID.STEEL_BAR, "Steel bar", 775)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smelting_steel_bars",
			""));
		add(new MoneyMethod(
			"Smithing steel cannonballs", Skill.SMITHING, true, false,
			reqs(Skill.SMITHING, 35),
			quests(Quest.DWARF_CANNON),
			list(
				item(ItemID.STEEL_BAR, "Steel bar", 600)),
			list(
				item(ItemID.MCANNONBALL, "Steel cannonball", 2400)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smithing_cannonballs",
			""));
		add(new MoneyMethod(
			"Smelting steel bars at Blast Furnace", Skill.SMITHING, true, false,
			reqs(Skill.SMITHING, 30),
			quests(Quest.THE_GIANT_DWARF),
			list(
				item(ItemID.COINS, "Coins", 72000),
				item(ItemID.IRON_ORE, "Iron ore", 5400),
				item(ItemID.COAL, "Coal", 5400),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 9)),
			list(
				item(ItemID.STEEL_BAR, "Steel bar", 5400)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smelting_steel_bars_at_Blast_Furnace",
			"Below 60 Smithing the foreman fee is extra."));
		add(new MoneyMethod(
			"Smelting mithril bars at Blast Furnace", Skill.SMITHING, true, false,
			reqs(Skill.SMITHING, 50),
			quests(Quest.THE_GIANT_DWARF),
			list(
				item(ItemID.COINS, "Coins", 72000),
				item(ItemID.MITHRIL_ORE, "Mithril ore", 3600),
				item(ItemID.COAL, "Coal", 7200),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 9)),
			list(
				item(ItemID.MITHRIL_BAR, "Mithril bar", 3600)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smelting_mithril_bars_at_Blast_Furnace",
			"Assumes a coal bag."));
		add(new MoneyMethod(
			"Smelting adamantite bars at Blast Furnace", Skill.SMITHING, true, false,
			reqs(Skill.SMITHING, 70),
			quests(Quest.THE_GIANT_DWARF),
			list(
				item(ItemID.COINS, "Coins", 72000),
				item(ItemID.ADAMANTITE_ORE, "Adamantite ore", 2700),
				item(ItemID.COAL, "Coal", 8100),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 9)),
			list(
				item(ItemID.ADAMANTITE_BAR, "Adamantite bar", 2700)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smelting_adamantite_bars_at_Blast_Furnace",
			""));
		add(new MoneyMethod(
			"Smelting runite bars at Blast Furnace", Skill.SMITHING, true, false,
			reqs(Skill.SMITHING, 85),
			quests(Quest.THE_GIANT_DWARF),
			list(
				item(ItemID.COINS, "Coins", 72000),
				item(ItemID.RUNITE_ORE, "Runite ore", 2160),
				item(ItemID.COAL, "Coal", 8640),
				item(ItemID._4DOSE2STAMINA, "Extended stamina potion(4)", 4)),
			list(
				item(ItemID.RUNITE_BAR, "Runite bar", 2160)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Smelting_runite_bars_at_Blast_Furnace",
			""));
		add(new MoneyMethod(
			"Salvaging small shipwrecks", Skill.SAILING, true, false,
			reqs(Skill.SAILING, 15),
			quests(Quest.PANDEMONIUM),
			list(),
			list(
				item(ItemID.BRONZE_BAR, "Bronze bar", 16.32),
				item(ItemID.LOGS, "Logs", 16.22),
				item(ItemID.NAILS_BRONZE, "Bronze nails", 47.95),
				item(ItemID.OAK_LOGS, "Oak logs", 8.25),
				item(ItemID.COINS, "Coins", 828),
				item(ItemID.WOODPLANK, "Plank", 8.23),
				item(ItemID.BRONZE_CANNONBALL, "Bronze cannonball", 24.62),
				item(ItemID.NAILS_IRON, "Iron nails", 24.1),
				item(ItemID.WATERRUNE, "Water rune", 44.15),
				item(ItemID.AIRRUNE, "Air rune", 44.08),
				item(ItemID.IRON_CANNONBALL, "Iron cannonball", 12.44),
				item(ItemID.PLANK_OAK, "Oak plank", 4.13),
				item(ItemID.IRON_BAR, "Iron bar", 4.02),
				item(ItemID.STEEL_ARROW, "Steel arrow", 4.92)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Salvaging_small_shipwrecks",
			""));
		add(new MoneyMethod(
			"Deep sea trawling for yellowfin", Skill.SAILING, true, false,
			reqs(Skill.FISHING, 79, Skill.CONSTRUCTION, 72),
			quests(Quest.PANDEMONIUM),
			list(
				item(ItemID.SLAYER_ICY_WATER, "Ice cooler", 90),
				item(ItemID.BOAT_REPAIR_KIT_TEAK, "Teak repair kit", 8),
				item(ItemID.BRUT_FISH_CUTS, "Fish offcuts", 40)),
			list(
				item(ItemID.RAW_YELLOWFIN, "Raw yellowfin", 805),
				item(ItemID.RAW_HALIBUT, "Raw halibut", 70),
				item(ItemID.RAW_BLUEFIN, "Raw bluefin", 17),
				item(ItemID.RAW_MARLIN, "Raw marlin", 8)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Deep_sea_trawling_for_yellowfin",
			"Needs a crewmate with Helmsmanship 3+."));
		add(new MoneyMethod(
			"Deep sea trawling for bluefin", Skill.SAILING, true, false,
			reqs(Skill.SAILING, 72, Skill.FISHING, 87),
			quests(Quest.PANDEMONIUM),
			list(
				item(ItemID.SLAYER_ICY_WATER, "Ice cooler", 79.5),
				item(ItemID.SAILING_FINE_FISH_OFFCUTS, "Fine fish offcuts", 40)),
			list(
				item(ItemID.RAW_BLUEFIN, "Raw bluefin", 720),
				item(ItemID.RAW_MARLIN, "Raw marlin", 75)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Deep_sea_trawling_for_bluefin",
			"Needs a crewmate with Helmsmanship 3+."));
		add(new MoneyMethod(
			"Deep sea trawling for marlin", Skill.SAILING, true, false,
			reqs(Skill.SAILING, 78, Skill.FISHING, 91, Skill.CONSTRUCTION, 72),
			quests(Quest.PANDEMONIUM),
			list(
				item(ItemID.SLAYER_ICY_WATER, "Ice cooler", 72.5),
				item(ItemID.BOAT_REPAIR_KIT_IRONWOOD, "Ironwood repair kit", 8),
				item(ItemID.SAILING_FINE_FISH_OFFCUTS, "Fine fish offcuts", 65)),
			list(
				item(ItemID.RAW_MARLIN, "Raw marlin", 650),
				item(ItemID.RAW_BLUEFIN, "Raw bluefin", 75)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Deep_sea_trawling_for_marlin",
			"Needs a crewmate with Helmsmanship 3+."));
		add(new MoneyMethod(
			"Deep sea trawling for halibut", Skill.SAILING, true, false,
			reqs(Skill.SAILING, 84, Skill.FISHING, 83, Skill.CONSTRUCTION, 73),
			quests(Quest.PANDEMONIUM),
			list(
				item(ItemID.SLAYER_ICY_WATER, "Ice cooler", 85.5),
				item(ItemID.SAILING_FINE_FISH_OFFCUTS, "Fine fish offcuts", 45)),
			list(
				item(ItemID.RAW_HALIBUT, "Raw halibut", 755),
				item(ItemID.RAW_YELLOWFIN, "Raw yellowfin", 75),
				item(ItemID.RAW_BLUEFIN, "Raw bluefin", 17),
				item(ItemID.RAW_MARLIN, "Raw marlin", 8)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Deep_sea_trawling_for_halibut",
			"Needs a crewmate with Helmsmanship 3+."));
		add(new MoneyMethod(
			"Crafting gold jewellery", Skill.CRAFTING, false, false,
			reqs(Skill.CRAFTING, 6),
			quests(),
			list(
				item(ItemID.GOLD_BAR, "Gold bar", 1400)),
			list(
				item(ItemID.GOLD_NECKLACE, "Gold necklace", 1400)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_gold_jewellery",
			""));
		add(new MoneyMethod(
			"Spinning flax to bow strings", Skill.CRAFTING, true, false,
			reqs(Skill.CRAFTING, 10),
			quests(),
			list(
				item(ItemID.FLAX_BALE, "Bale of flax", 80)),
			list(
				item(ItemID.BOW_STRING, "Bow string", 2000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Spinning_flax_to_bow_strings",
			"Rate assumes an upgraded bow string spool."));
		add(new MoneyMethod(
			"Crafting drift nets", Skill.CRAFTING, true, false,
			reqs(Skill.CRAFTING, 26),
			quests(),
			list(
				item(ItemID.JUTE_FIBRE, "Jute fibre", 2200)),
			list(
				item(ItemID.FOSSIL_DRIFT_NET, "Drift net", 1100)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_drift_nets",
			""));
		add(new MoneyMethod(
			"Crafting topaz jewellery", Skill.CRAFTING, true, false,
			reqs(Skill.CRAFTING, 45),
			quests(),
			list(
				item(ItemID.SILVER_BAR, "Silver bar", 1200),
				item(ItemID.RED_TOPAZ, "Red topaz", 1200)),
			list(
				item(ItemID.UNSTRUNG_TOPAZ_AMULET, "Topaz amulet (u)", 1200)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_topaz_jewellery",
			""));
		add(new MoneyMethod(
			"Crafting diamond jewellery", Skill.CRAFTING, false, false,
			reqs(Skill.CRAFTING, 56),
			quests(),
			list(
				item(ItemID.GOLD_BAR, "Gold bar", 1200),
				item(ItemID.DIAMOND, "Diamond", 1200)),
			list(
				item(ItemID.DIAMOND_NECKLACE, "Diamond necklace", 1200)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_diamond_jewellery",
			""));
		add(new MoneyMethod(
			"Making toy cats", Skill.CRAFTING, true, false,
			reqs(Skill.CRAFTING, 85, Skill.CONSTRUCTION, 42),
			quests(),
			list(
				item(ItemID.COINS, "Coins", 62880),
				item(ItemID.POH_CLOCKWORK_MECHANISM, "Clockwork", 576),
				item(ItemID.WOODPLANK, "Plank", 576)),
			list(
				item(ItemID.POH_TOY_CAT, "Toy cat", 576)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_toy_cats",
			"Very slow to sell."));
		add(new MoneyMethod(
			"Fletching ogre arrow shafts", Skill.FLETCHING, true, false,
			reqs(Skill.FLETCHING, 5),
			quests(Quest.ZOGRE_FLESH_EATERS),
			list(
				item(ItemID.COINS, "Coins", 14400)),
			list(
				item(ItemID.OGRE_ARROW_SHAFT, "Ogre arrow shaft", 7200)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Fletching_ogre_arrow_shafts",
			""));
		add(new MoneyMethod(
			"Making adamant brutal arrows", Skill.FLETCHING, true, false,
			reqs(Skill.FLETCHING, 62),
			quests(Quest.ZOGRE_FLESH_EATERS),
			list(
				item(ItemID.OGRE_HEADLESS_ARROW, "Flighted ogre arrow", 15000),
				item(ItemID.NAILS_ADAMANT, "Adamantite nails", 15000)),
			list(
				item(ItemID.ZOGRE_BRUTAL_ADAMANT, "Adamant brutal", 15000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_adamant_brutal_arrows",
			""));
		add(new MoneyMethod(
			"Fletching moonlight antler bolts", Skill.FLETCHING, true, false,
			reqs(Skill.FLETCHING, 72),
			quests(),
			list(
				item(ItemID.HUNTING_ANTELOPEMOON_HORN, "Moonlight antelope antler", 1800)),
			list(
				item(ItemID.MOONLIGHT_ANTELOPE_BOLT, "Moonlight antler bolts", 21600)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Fletching_moonlight_antler_bolts",
			""));
		add(new MoneyMethod(
			"Fletching gem-tipped dragon bolts", Skill.FLETCHING, true, false,
			reqs(Skill.FLETCHING, 84),
			quests(),
			list(
				item(ItemID.XBOWS_BOLT_TIPS_RUBY, "Ruby bolt tips", 27000),
				item(ItemID.DRAGON_BOLTS, "Dragon bolts", 27000)),
			list(
				item(ItemID.DRAGON_BOLTS_UNENCHANTED_RUBY, "Ruby dragon bolts", 27000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Fletching_gem-tipped_dragon_bolts",
			"Very high capital."));
		add(new MoneyMethod(
			"Stringing magic longbows", Skill.FLETCHING, true, false,
			reqs(Skill.FLETCHING, 85),
			quests(),
			list(
				item(ItemID.UNSTRUNG_MAGIC_LONGBOW, "Magic longbow (u)", 2400),
				item(ItemID.BOW_STRING, "Bow string", 2400)),
			list(
				item(ItemID.MAGIC_LONGBOW, "Magic longbow", 2400)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Stringing_magic_longbows",
			""));
		add(new MoneyMethod(
			"Making tarromin potions", Skill.HERBLORE, true, false,
			reqs(Skill.HERBLORE, 12),
			quests(Quest.DRUIDIC_RITUAL),
			list(
				item(ItemID.TARROMIN, "Tarromin", 4000),
				item(ItemID.VIAL_WATER, "Vial of water", 4000)),
			list(
				item(ItemID.TARROMINVIAL, "Tarromin potion (unf)", 4000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_tarromin_potions",
			""));
		add(new MoneyMethod(
			"Making harralander potions", Skill.HERBLORE, true, false,
			reqs(Skill.HERBLORE, 22),
			quests(Quest.DRUIDIC_RITUAL),
			list(
				item(ItemID.HARRALANDER, "Harralander", 4000),
				item(ItemID.VIAL_WATER, "Vial of water", 4000)),
			list(
				item(ItemID.HARRALANDERVIAL, "Harralander potion (unf)", 4000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_harralander_potions",
			""));
		add(new MoneyMethod(
			"Making ranarr potions", Skill.HERBLORE, true, false,
			reqs(Skill.HERBLORE, 30),
			quests(Quest.DRUIDIC_RITUAL),
			list(
				item(ItemID.RANARR_WEED, "Ranarr weed", 4000),
				item(ItemID.VIAL_WATER, "Vial of water", 4000)),
			list(
				item(ItemID.RANARRVIAL, "Ranarr potion (unf)", 4000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_ranarr_potions",
			""));
		add(new MoneyMethod(
			"Making prayer potions", Skill.HERBLORE, true, false,
			reqs(Skill.HERBLORE, 38),
			quests(Quest.DRUIDIC_RITUAL),
			list(
				item(ItemID.SNAPE_GRASS, "Snape grass", 2250),
				item(ItemID.RANARR_WEED, "Ranarr weed", 2500),
				item(ItemID.VIAL_WATER, "Vial of water", 2500),
				item(ItemID.COINS, "Coins", 500000)),
			list(
				item(ItemID._4DOSEPRAYERRESTORE, "Prayer potion(4)", 1969)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_prayer_potions",
			"Zahur's fees included. Alchemist's amulet charges not counted."));
		add(new MoneyMethod(
			"Cleaning grimy cadantine", Skill.HERBLORE, true, false,
			reqs(Skill.HERBLORE, 65),
			quests(Quest.DRUIDIC_RITUAL),
			list(
				item(ItemID.UNIDENTIFIED_CADANTINE, "Grimy cadantine", 5000)),
			list(
				item(ItemID.CADANTINE, "Cadantine", 5000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Cleaning_grimy_cadantine",
			""));
		add(new MoneyMethod(
			"Making sanfew serum(4)", Skill.HERBLORE, true, false,
			reqs(Skill.HERBLORE, 65),
			quests(Quest.DRUIDIC_RITUAL, Quest.ZOGRE_FLESH_EATERS),
			list(
				item(ItemID.NAIL_BEAST_NAIL, "Nail beast nails", 250),
				item(ItemID.UNICORN_HORN_DUST, "Unicorn horn dust", 250),
				item(ItemID._4DOSE2RESTORE, "Super restore(4)", 250)),
			list(
				item(ItemID.SANFEW_SALVE_4_DOSE, "Sanfew serum(4)", 250)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_sanfew_serum(4)",
			"Snake weed must be gathered yourself."));
		add(new MoneyMethod(
			"Collecting ashes", Skill.FIREMAKING, false, false,
			reqs(Skill.FIREMAKING, 30),
			quests(),
			list(
				item(ItemID.MAPLE_LOGS, "Maple logs", 1000)),
			list(
				item(ItemID.ASHES, "Ashes", 1000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Collecting_ashes",
			""));
		add(new MoneyMethod(
			"Making magic pyre logs", Skill.FIREMAKING, true, false,
			reqs(Skill.FIREMAKING, 1),
			quests(Quest.SHADES_OF_MORTTON),
			list(
				item(ItemID.SACRED_OIL4, "Sacred oil(4)", 1400),
				item(ItemID.MAGIC_LOGS, "Magic logs", 1400)),
			list(
				item(ItemID.MAGIC_LOGS_PYRE, "Magic pyre logs", 1400),
				item(ItemID.VIAL_EMPTY, "Vial", 1400)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_magic_pyre_logs",
			"Sacred oil is in short supply."));
		add(new MoneyMethod(
			"Making redwood pyre logs", Skill.FIREMAKING, true, false,
			reqs(Skill.FIREMAKING, 1),
			quests(Quest.SHADES_OF_MORTTON),
			list(
				item(ItemID.SACRED_OIL4, "Sacred oil(4)", 1400),
				item(ItemID.REDWOOD_LOGS, "Redwood logs", 1400)),
			list(
				item(ItemID.REDWOOD_LOGS_PYRE, "Redwood pyre logs", 1400),
				item(ItemID.VIAL_EMPTY, "Vial", 1400)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Making_redwood_pyre_logs",
			""));
		add(new MoneyMethod(
			"Crafting cosmic runes", Skill.RUNECRAFT, true, false,
			reqs(Skill.RUNECRAFT, 59),
			quests(Quest.LOST_CITY),
			list(
				item(ItemID.BLANKRUNE_HIGH, "Pure essence", 2640),
				item(ItemID.ASTRALRUNE, "Astral rune", 5),
				item(ItemID.COSMICRUNE, "Cosmic rune", 5)),
			list(
				item(ItemID.COSMICRUNE, "Cosmic rune", 8976)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_cosmic_runes",
			"Rates assume double cosmics (59) and the Raiments of the Eye."));
		add(new MoneyMethod(
			"Crafting blood runes", Skill.RUNECRAFT, true, false,
			reqs(Skill.RUNECRAFT, 77),
			quests(Quest.SINS_OF_THE_FATHER),
			list(
				item(ItemID.BLANKRUNE_HIGH, "Pure essence", 4620),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 4),
				item(ItemID.BLOOD_ESSENCE_INACTIVE, "Blood essence", 2.31)),
			list(
				item(ItemID.BLOODRUNE, "Blood rune", 10626)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_blood_runes",
			""));
		add(new MoneyMethod(
			"Crafting astral runes", Skill.RUNECRAFT, true, false,
			reqs(Skill.RUNECRAFT, 85),
			quests(Quest.LUNAR_DIPLOMACY),
			list(
				item(ItemID.BLANKRUNE_HIGH, "Pure essence", 5016),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 7.6)),
			list(
				item(ItemID.ASTRALRUNE, "Astral rune", 17054)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_astral_runes",
			"Lunar spellbook teleports."));
		add(new MoneyMethod(
			"Crafting wrath runes", Skill.RUNECRAFT, true, false,
			reqs(Skill.RUNECRAFT, 95),
			quests(Quest.DRAGON_SLAYER_II),
			list(
				item(ItemID.BLANKRUNE_HIGH, "Pure essence", 5280)),
			list(
				item(ItemID.WRATHRUNE, "Wrath rune", 8448)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_wrath_runes",
			""));
		add(new MoneyMethod(
			"Crafting nature runes through the Abyss", Skill.RUNECRAFT, true, false,
			reqs(Skill.RUNECRAFT, 44, Skill.MINING, 21, Skill.HITPOINTS, 70),
			quests(Quest.ENTER_THE_ABYSS),
			list(
				item(ItemID.BLANKRUNE_HIGH, "Pure essence", 2970),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 7.5),
				item(ItemID.MONKFISH, "Monkfish", 10),
				item(ItemID.AMULET_OF_GLORY_6, "Amulet of glory(6)", 9.17)),
			list(
				item(ItemID.NATURERUNE, "Nature rune", 4752),
				item(ItemID.AMULET_OF_GLORY, "Amulet of glory", 9.17)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_nature_runes_through_the_Abyss",
			""));
		add(new MoneyMethod(
			"Crafting death runes through the Abyss", Skill.RUNECRAFT, true, false,
			reqs(Skill.RUNECRAFT, 65, Skill.MINING, 21, Skill.HITPOINTS, 70),
			quests(Quest.ENTER_THE_ABYSS, Quest.MOURNINGS_END_PART_II),
			list(
				item(ItemID.BLANKRUNE_HIGH, "Pure essence", 3350),
				item(ItemID._4DOSESTAMINA, "Stamina potion(4)", 4),
				item(ItemID.MONKFISH, "Monkfish", 10),
				item(ItemID.AMULET_OF_GLORY_6, "Amulet of glory(6)", 8.33)),
			list(
				item(ItemID.DEATHRUNE, "Death rune", 11390),
				item(ItemID.AMULET_OF_GLORY, "Amulet of glory", 8.33)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Crafting_death_runes_through_the_Abyss",
			""));
		add(new MoneyMethod(
			"Pickpocketing master farmers", Skill.THIEVING, true, false,
			reqs(Skill.THIEVING, 38),
			quests(),
			list(),
			list(
				item(ItemID.WATERMELON_SEED, "Watermelon seed", 31.75),
				item(ItemID.SNAPE_GRASS_SEED, "Snape grass seed", 23.08),
				item(ItemID.BARLEY_SEED, "Barley seed", 2167),
				item(ItemID.HAMMERSTONE_HOP_SEED, "Hammerstone seed", 1667),
				item(ItemID.ASGARNIAN_HOP_SEED, "Asgarnian seed", 879),
				item(ItemID.JUTE_SEED, "Jute seed", 1245),
				item(ItemID.YANILLIAN_HOP_SEED, "Yanillian seed", 582),
				item(ItemID.KRANDORIAN_HOP_SEED, "Krandorian seed", 291),
				item(ItemID.WILDBLOOD_HOP_SEED, "Wildblood seed", 84.51),
				item(ItemID.DWARF_WEED_SEED, "Dwarf weed seed", 0.86),
				item(ItemID.LANTADYME_SEED, "Lantadyme seed", 1.44),
				item(ItemID.CADANTINE_SEED, "Cadantine seed", 2.02),
				item(ItemID.RANARR_SEED, "Ranarr seed", 22.65),
				item(ItemID.TOADFLAX_SEED, "Toadflax seed", 13.54),
				item(ItemID.AVANTOE_SEED, "Avantoe seed", 6.34),
				item(ItemID.KWUARM_SEED, "Kwuarm seed", 4.32),
				item(ItemID.SNAPDRAGON_SEED, "Snapdragon seed", 3.24),
				item(ItemID.TORSTOL_SEED, "Torstol seed", 0.65)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Pickpocketing_master_farmers",
			"Rates at 94 Thieving with Rogue equipment; much lower at 38."));
		add(new MoneyMethod(
			"Pickpocketing Knights of Ardougne", Skill.THIEVING, true, false,
			reqs(Skill.THIEVING, 55),
			quests(),
			list(
				item(ItemID.JUG_WINE, "Jug of wine", 15)),
			list(
				item(ItemID.COINS, "Coins", 300000)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Pickpocketing_Knights_of_Ardougne",
			"Medium Ardougne Diary recommended."));
		add(new MoneyMethod(
			"Pickpocketing paladins", Skill.THIEVING, true, false,
			reqs(Skill.THIEVING, 70, Skill.AGILITY, 50),
			quests(),
			list(
				item(ItemID.COINS, "Coins", 5000),
				item(ItemID.DODGY_NECKLACE, "Dodgy necklace", 8.28)),
			list(
				item(ItemID.COINS, "Coins", 183200),
				item(ItemID.CHAOSRUNE, "Chaos rune", 4580)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Pickpocketing_paladins",
			"Rates at 99 Thieving; about 346k/hr at 70."));
		add(new MoneyMethod(
			"Pickpocketing vyres", Skill.THIEVING, true, false,
			reqs(Skill.THIEVING, 82, Skill.AGILITY, 50),
			quests(Quest.SINS_OF_THE_FATHER),
			list(
				item(ItemID.DODGY_NECKLACE, "Dodgy necklace", 6.04)),
			list(
				item(ItemID.BLOOD_SHARD, "Blood shard", 0.29),
				item(ItemID.COINS, "Coins", 298759),
				item(ItemID.DEATHRUNE, "Death rune", 175),
				item(ItemID.BLOODRUNE, "Blood rune", 87.27),
				item(ItemID.BLOOD_PINT, "Blood pint", 65.45),
				item(ItemID.UNCUT_RUBY, "Uncut ruby", 54.55),
				item(ItemID.DIAMOND, "Diamond", 10.91),
				item(ItemID.COOKED_MYSTERY_MEAT, "Cooked mystery meat", 10.91)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Pickpocketing_vyres",
			"Rates at 99 Thieving. Hard Ardougne Diary."));
		add(new MoneyMethod(
			"Pickpocketing elves", Skill.THIEVING, true, false,
			reqs(Skill.THIEVING, 85, Skill.AGILITY, 50),
			quests(Quest.SONG_OF_THE_ELVES),
			list(
				item(ItemID.DODGY_NECKLACE, "Dodgy necklace", 16.18)),
			list(
				item(ItemID.PRIF_TELEPORT_SEED, "Enhanced crystal teleport seed", 1.09),
				item(ItemID.COINS, "Coins", 289406),
				item(ItemID.DEATHRUNE, "Death rune", 140),
				item(ItemID.NATURERUNE, "Nature rune", 131),
				item(ItemID.FIRE_ORB, "Fire orb", 17.5),
				item(ItemID.DIAMOND, "Diamond", 8.75),
				item(ItemID.GOLD_ORE, "Gold ore", 8.75)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Pickpocketing_elves",
			"Rates at 99 Thieving. Crystal shards not counted."));
		add(new MoneyMethod(
			"Farming hemp", Skill.FARMING, true, true,
			reqs(Skill.FARMING, 37),
			quests(),
			list(
				item(ItemID.HEMP_SEED, "Hemp seed", 15),
				item(ItemID.BUCKET_ULTRACOMPOST, "Ultracompost", 2.5),
				item(ItemID.FLAX, "Flax", 30),
				item(ItemID.CHRONICLE_TELE_CARD, "Teleport card", 1)),
			list(
				item(ItemID.HEMP, "Hemp", 125)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Farming_hemp",
			"One 5-patch run, about every 80 minutes."));
		add(new MoneyMethod(
			"Farming ranarr weed", Skill.FARMING, true, true,
			reqs(Skill.FARMING, 32, Skill.MAGIC, 61),
			quests(Quest.GHOSTS_AHOY, Quest.MY_ARMS_BIG_ADVENTURE, Quest.FAIRYTALE_I__GROWING_PAINS),
			list(
				item(ItemID.RANARR_SEED, "Ranarr seed", 10),
				item(ItemID.BUCKET_ULTRACOMPOST, "Ultracompost", 10)),
			list(
				item(ItemID.UNIDENTIFIED_RANARR, "Grimy ranarr weed", 88)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Farming_ranarr_weed",
			"One 10-patch herb run, about every 90 minutes."));
		add(new MoneyMethod(
			"Farming snapdragon", Skill.FARMING, true, true,
			reqs(Skill.FARMING, 62, Skill.MAGIC, 61),
			quests(Quest.GHOSTS_AHOY, Quest.MY_ARMS_BIG_ADVENTURE, Quest.FAIRYTALE_I__GROWING_PAINS),
			list(
				item(ItemID.SNAPDRAGON_SEED, "Snapdragon seed", 10),
				item(ItemID.BUCKET_ULTRACOMPOST, "Ultracompost", 10)),
			list(
				item(ItemID.UNIDENTIFIED_SNAPDRAGON, "Grimy snapdragon", 88)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Farming_snapdragon",
			"One 10-patch herb run, about every 90 minutes."));
		add(new MoneyMethod(
			"Farming torstol", Skill.FARMING, true, true,
			reqs(Skill.FARMING, 85, Skill.MAGIC, 61),
			quests(Quest.GHOSTS_AHOY, Quest.MY_ARMS_BIG_ADVENTURE, Quest.FAIRYTALE_I__GROWING_PAINS),
			list(
				item(ItemID.TORSTOL_SEED, "Torstol seed", 10),
				item(ItemID.BUCKET_ULTRACOMPOST, "Ultracompost", 10)),
			list(
				item(ItemID.UNIDENTIFIED_TORSTOL, "Grimy torstol", 88)),
			"https://oldschool.runescape.wiki/w/Money_making_guide/Farming_torstol",
			"One 10-patch herb run, about every 90 minutes."));
	}

	private MethodData()
	{
	}

	static List<MoneyMethod> all()
	{
		return Collections.unmodifiableList(METHODS);
	}

	private static void add(MoneyMethod m)
	{
		METHODS.add(m);
	}

	private static Map<Skill, Integer> reqs(Object... pairs)
	{
		Map<Skill, Integer> map = new EnumMap<>(Skill.class);
		for (int i = 0; i < pairs.length; i += 2)
		{
			map.put((Skill) pairs[i], (Integer) pairs[i + 1]);
		}
		return map;
	}

	private static List<Quest> quests(Quest... quests)
	{
		return Arrays.asList(quests);
	}

	private static List<ItemAmount> list(ItemAmount... items)
	{
		return Arrays.asList(items);
	}

	private static ItemAmount item(int id, String name, double perHour)
	{
		return new ItemAmount(id, name, perHour);
	}
}
