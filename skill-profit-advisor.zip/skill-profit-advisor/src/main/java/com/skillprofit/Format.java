/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.util.Locale;

/**
 * Short gp and quantity text for the panel: 608k, 2.4M, 1,700.
 */
final class Format
{
	private Format()
	{
	}

	static String gp(long value)
	{
		long abs = Math.abs(value);
		String sign = value < 0 ? "-" : "";
		if (abs >= 10_000_000)
		{
			return sign + (abs / 1_000_000) + "M";
		}
		if (abs >= 1_000_000)
		{
			return sign + String.format(Locale.ROOT, "%.1fM", abs / 1_000_000.0);
		}
		if (abs >= 10_000)
		{
			return sign + (abs / 1_000) + "k";
		}
		return sign + String.format(Locale.ROOT, "%,d", abs);
	}

	static String qty(double q)
	{
		if (q >= 100 || q == Math.rint(q))
		{
			return String.format(Locale.ROOT, "%,d", Math.round(q));
		}
		return String.format(Locale.ROOT, "%.2f", q);
	}
}
