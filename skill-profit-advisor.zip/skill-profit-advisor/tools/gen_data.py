"""Regenerate src/main/java/com/skillprofit/MethodData.java from methods.py.

    python3 tools/gen_data.py <runelite>/runelite-api/src/main/java/net/runelite/api/Quest.java \
        <runelite>/runelite-api/src/main/java/net/runelite/api/gameval/ItemID.java \
        src/main/java/com/skillprofit/MethodData.java

Item names are matched to gameval ItemID constants by their javadoc display name (the
lowest-id real item; test/placeholder variants skipped; OVERRIDE for the exceptions),
quest names to net.runelite.api.Quest constants. Fails loudly on anything unmatched.
"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from methods import M

_isrc = open(sys.argv[2]).read()
IDX = {}
for _name, _const, _id in re.findall(r'/\*\*\s*\n\s*\*\s*(.+?)\s*\n\s*\*/\s*\n\s*public static final int (\w+) = (\d+);', _isrc):
    IDX.setdefault(_name.lower(), []).append((int(_id), _const))
BAD = ("FAKE_", "BR_", "POH_TROPHY", "POH_SHIELD", "CERT_", "MAGICTRAINING", "DEADMAN", "ROGUETRADER", "_100GUIDE",
       "SLUG2_", "NEWBIE", "TUT2_", "GAUNTLET_", "HUNTGUIDE_", "SAILING_SKILLGUIDE", "CASTLE_DRAKAN", "LUNAR_MOONCLAN")
# items whose real version is NOT the lowest id of that name
OVERRIDE = {"Chinchompa": (10033, "CHINCHOMPA_CAPTURED"), "Red chinchompa": (10034, "CHINCHOMPA_BIG_CAPTURED")}


def resolve(name):
    if name in OVERRIDE:
        return OVERRIDE[name]
    cands = sorted(IDX.get(name.lower(), []))
    good = [c for c in cands if not any(b in c[1] for b in BAD)]
    return (good or cands or [None])[0]


qsrc = open(sys.argv[1]).read()
QUEST = {name: const for const, name in re.findall(r'^\s*(\w+)\(\d+, "([^"]+)"\)', qsrc, re.M)}
SK = {s: s.upper() for s in ["Mining","Smithing","Fishing","Cooking","Woodcutting","Firemaking","Crafting","Fletching",
      "Herblore","Runecraft","Agility","Thieving","Farming","Construction","Hunter","Sailing","Magic","Hitpoints",
      "Prayer","Ranged","Attack","Strength","Defence","Slayer"]}

def js(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'

def items(lst):
    out = []
    for name, q in lst:
        r = resolve(name)
        assert r, name
        out.append(f"\t\t\t\titem(ItemID.{r[1]}, {js(name)}, {q!r})")
    return "list(\n" + ",\n".join(out) + ")" if out else "list()"

rows = []
for x in M:
    reqs = ", ".join(f"Skill.{SK[k]}, {v}" for k, v in x["reqs"].items())
    qs = ", ".join("Quest." + QUEST[q] for q in x["quests"])
    for q in x["quests"]:
        assert q in QUEST, q
    rows.append(
        f"\t\tadd(new MoneyMethod(\n\t\t\t{js(x['title'])}, Skill.{SK[x['skill']]}, {str(x['members']).lower()}, {str(x['per_run']).lower()},\n"
        f"\t\t\treqs({reqs}),\n"
        f"\t\t\tquests({qs}),\n"
        f"\t\t\t{items(x['inputs'])},\n"
        f"\t\t\t{items(x['outputs'])},\n"
        f"\t\t\t{js(x['url'])},\n"
        f"\t\t\t{js(x['note'])}));")

java = '''/*
 * Copyright (c) 2026, Cory
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.skillprofit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.runelite.api.Quest;
import net.runelite.api.Skill;
import net.runelite.api.gameval.ItemID;

/**
 * The method table, GENERATED from the OSRS Wiki money-making guides (fetched 2026-10-07)
 * by gen_data.py. Quantities are per hour (per run for farming runs), exactly as on each
 * guide; profit is never stored here, it is recalculated from live Grand Exchange prices.
 */
final class MethodData
{
	private static final List<MoneyMethod> METHODS = new ArrayList<>();

	static
	{
%ROWS%
	}

	private MethodData()
	{
	}

	static List<MoneyMethod> all()
	{
		return Collections.unmodifiableList(METHODS);
	}

	private static void add(MoneyMethod m)
	{
		METHODS.add(m);
	}

	private static Map<Skill, Integer> reqs(Object... pairs)
	{
		Map<Skill, Integer> map = new EnumMap<>(Skill.class);
		for (int i = 0; i < pairs.length; i += 2)
		{
			map.put((Skill) pairs[i], (Integer) pairs[i + 1]);
		}
		return map;
	}

	private static List<Quest> quests(Quest... quests)
	{
		return Arrays.asList(quests);
	}

	private static List<ItemAmount> list(ItemAmount... items)
	{
		return Arrays.asList(items);
	}

	private static ItemAmount item(int id, String name, double perHour)
	{
		return new ItemAmount(id, name, perHour);
	}
}
'''.replace("%ROWS%", "\n".join(rows))
open(sys.argv[3], "w").write(java)
print(len(M), "methods")
