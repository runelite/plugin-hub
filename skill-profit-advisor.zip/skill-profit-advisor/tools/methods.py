"""Curated non-combat money-making methods, from OSRS Wiki money-making guides
(fetched 2026-10-07). Quantities are per hour (or per run where per_run=True), exactly as on
each guide page. Profit is NOT stored: the plugin recomputes it from live GE prices.

Edits from the pages, each noted:
  * inputs that are spell casts / charges (not items) are left out;
  * untradeable outputs are kept (they price at 0 and simply add nothing);
  * Shadow Veil cosmic runes are dropped from thieving methods (needs Magic, optional).
"""

W = "https://oldschool.runescape.wiki/w/Money_making_guide/"

M = []


def m(title, skill, reqs, members, inputs, outputs, url=None, quests=(), note="", per_run=False):
    M.append(dict(title=title, skill=skill, reqs=reqs, members=members, inputs=inputs, outputs=outputs,
                  url=url or W + title.replace(" ", "_"), quests=list(quests), note=note, per_run=per_run))


# ---------------------------------------------------------------- Mining
m("Mining iron ore", "Mining", {"Mining": 15}, True, [],
  [("Iron ore", 1700), ("Uncut sapphire", 6.61), ("Uncut emerald", 3.31), ("Uncut ruby", 1.66), ("Uncut diamond", 0.41)],
  note="Rates assume the Mining Guild (60+).")
m("Mining coal", "Mining", {"Mining": 30}, True, [], [("Coal", 350)], note="60+ (Mining Guild) recommended.")
m("Mining gold ore", "Mining", {"Mining": 40}, True, [], [("Gold ore", 500)])
m("Mining basalt", "Mining", {"Mining": 72}, True, [], [("Basalt", 700)], quests=["Making Friends with My Arm"])
m("Mining runite ore", "Mining", {"Mining": 85}, True, [], [("Runite ore", 65)], note="World-hopping between rocks.")
m("Mining amethyst", "Mining", {"Mining": 92}, True, [], [("Amethyst", 90)])
m("Mining lead ore (Deepfin mine)", "Mining", {"Mining": 25, "Sailing": 67, "Construction": 70}, True, [],
  [("Lead ore", 1800), ("Uncut sapphire", 7), ("Uncut emerald", 3.5), ("Uncut ruby", 1.75), ("Uncut diamond", 0.44)],
  quests=["Pandemonium"], note="Construction 70 to build the bank chest.")

# ---------------------------------------------------------------- Woodcutting
m("Cutting teak logs", "Woodcutting", {"Woodcutting": 35}, True, [("Ring of dueling(8)", 3)], [("Teak logs", 550)])
m("Cutting mahogany logs", "Woodcutting", {"Woodcutting": 50}, True, [("Ring of dueling(8)", 1.62)],
  [("Mahogany logs", 350)], quests=["Monkey Madness I"], note="Only part of Monkey Madness I is needed.")
m("Cutting yew logs", "Woodcutting", {"Woodcutting": 60}, True, [("Secateurs attachment", 52.5)],
  [("Yew logs", 210), ("Yew leaves", 105)],
  note="Forestry method (Forestry kit). Anima-infused bark is untradeable and not counted.")
m("Cutting magic logs", "Woodcutting", {"Woodcutting": 75}, True, [("Secateurs attachment", 32.5)],
  [("Magic logs", 130), ("Magic leaves", 65)])
m("Cutting redwood logs", "Woodcutting", {"Woodcutting": 90}, True, [], [("Redwood logs", 180)],
  note="Bird nests not counted.")

# ---------------------------------------------------------------- Hunter
m("Catching snowy knights", "Hunter", {"Hunter": 35}, True, [("Butterfly jar", 504), ("Ring of dueling(8)", 2.25)],
  [("Snowy knight", 504)], quests=["Fairytale II - Cure a Queen"], note="Fairy rings (part of Fairytale II).")
m("Hunting chinchompas", "Hunter", {"Hunter": 53}, True, [], [("Chinchompa", 225)], quests=["Eagles' Peak"])
m("Hunting pyre foxes", "Hunter", {"Hunter": 57}, True, [("Ring of dueling(8)", 1.46), ("Jerboa tail", 350)],
  [("Fox fur", 350), ("Raw pyre fox", 350)], quests=["Children of the Sun"])
m("Hunting carnivorous chinchompas", "Hunter", {"Hunter": 63}, True, [], [("Red chinchompa", 475)],
  quests=["Eagles' Peak"], note="80+ strongly recommended.")
m("Hunting sunlight antelopes", "Hunter", {"Hunter": 72, "Fletching": 62}, True, [("Stamina potion(4)", 2.75)],
  [("Sunlight antler bolts", 2640), ("Sunlight antelope fur", 220), ("Raw sunlight antelope", 220)],
  quests=["Children of the Sun"])
m("Hunting black chinchompas", "Hunter", {"Hunter": 80}, True, [("Steel dart", 37.5)], [("Black chinchompa", 300)],
  quests=["Eagles' Peak"], note="Wilderness: player-killer risk.")
m("Hunting herbiboars", "Hunter", {"Hunter": 80, "Herblore": 31, "Agility": 60}, True, [("Stamina potion(4)", 7.5)],
  [("Grimy guam leaf", 34.5), ("Grimy ranarr weed", 14.76), ("Grimy irit leaf", 13.26), ("Grimy avantoe", 14.94),
   ("Grimy kwuarm", 19.62), ("Grimy snapdragon", 12.42), ("Grimy cadantine", 20.46), ("Grimy lantadyme", 19.62),
   ("Grimy dwarf weed", 16.86), ("Grimy torstol", 13.56), ("Numulite", 802)], quests=["Bone Voyage"])

# ---------------------------------------------------------------- Agility
m("Climbing the Agility Pyramid", "Agility", {"Agility": 30, "Hitpoints": 20}, True, [], [("Coins", 200000)],
  note="Pyramid tops sold to Simon Templeton.")
m("Wilderness Agility Course", "Agility", {"Agility": 52}, True, [("Coins", 150000)],
  [("Rune kiteshield", 24.9), ("Rune chainbody", 24.9), ("Blighted super restore(4)", 118), ("Blighted anglerfish", 390),
   ("Blighted manta ray", 390), ("Blighted karambwan", 390), ("Rune med helm", 8.3), ("Adamant platebody", 8.3),
   ("Adamant platelegs", 4.15), ("Adamant full helm", 4.15), ("Mithril plateskirt", 4.15), ("Mithril platelegs", 4.15)],
  note="Wilderness: player-killer risk. Average dispenser rewards.")

# ---------------------------------------------------------------- Fishing
m("Catching shrimp & anchovies", "Fishing", {"Fishing": 15}, False, [],
  [("Raw anchovies", 248), ("Raw shrimps", 372)], url=W + "Catching_shrimp_%26_anchovies")
m("Catching sardines & herring", "Fishing", {"Fishing": 10}, False, [("Fishing bait", 494)],
  [("Raw sardine", 262), ("Raw herring", 232)], url=W + "Catching_sardines_%26_herring")
m("Catching lobsters", "Fishing", {"Fishing": 40}, False, [("Coins", 493)], [("Raw lobster", 222)])
m("Catching monkfish", "Fishing", {"Fishing": 62}, True, [], [("Raw monkfish", 290)], quests=["Swan Song"])
m("Catching sharks", "Fishing", {"Fishing": 76}, True, [], [("Raw shark", 160)])
m("Catching minnows", "Fishing", {"Fishing": 82}, True, [], [("Raw shark", 375)], quests=["Fishing Contest"],
  note="Minnows traded for raw sharks. Needs the full Angler's outfit.")
m("Catching anglerfish", "Fishing", {"Fishing": 82}, True, [("Sandworms", 150)], [("Raw anglerfish", 150)])
m("Catching dark crabs", "Fishing", {"Fishing": 85}, True, [("Dark fishing bait", 308), ("Coins", 15400)],
  [("Raw dark crab", 308)], note="Wilderness: player-killer risk.")

# ---------------------------------------------------------------- Cooking
m("Cooking raw anchovies", "Cooking", {"Cooking": 1}, False, [("Raw anchovies", 1300)], [("Anchovies", 1300)])
m("Cooking plain pizzas", "Cooking", {"Cooking": 35}, False, [("Pizza base", 540), ("Tomato", 540), ("Cheese", 540)],
  [("Plain pizza", 540)])
m("Making raw admiral pies", "Cooking", {"Cooking": 70}, True,
  [("Pie shell", 840), ("Salmon", 840), ("Tuna", 840), ("Potato", 840)], [("Raw admiral pie", 840)],
  note="Thin market: slow to sell.")
m("Making raw wild pies", "Cooking", {"Cooking": 85}, True,
  [("Pie shell", 740), ("Raw bear meat", 740), ("Raw rabbit", 740), ("Raw chompy", 740)], [("Raw wild pie", 740)])
m("Cutting raw yellowfin", "Cooking", {"Cooking": 1}, True, [("Raw yellowfin", 11000)],
  [("Fine fish offcuts", 11000), ("Yellow fin", 33000)], note="Sailing content. Low daily volume.")
m("Cutting raw marlin", "Cooking", {"Cooking": 90}, True, [("Raw marlin", 11000)],
  [("Fine fish offcuts", 11000), ("Marlin scales", 33000)], note="Sailing content. Low daily volume.")

# ---------------------------------------------------------------- Smithing
m("Smelting iron bars", "Smithing", {"Smithing": 15}, False, [("Iron ore", 980), ("Ring of forging", 7)],
  [("Iron bar", 980)], note="Ring of forging is a members item.")
m("Smelting steel bars", "Smithing", {"Smithing": 30}, False, [("Iron ore", 775), ("Coal", 1550)], [("Steel bar", 775)])
m("Smithing steel cannonballs", "Smithing", {"Smithing": 35}, True, [("Steel bar", 600)],
  [("Steel cannonball", 2400)], url=W + "Smithing_cannonballs", quests=["Dwarf Cannon"])
m("Smelting steel bars at Blast Furnace", "Smithing", {"Smithing": 30}, True,
  [("Coins", 72000), ("Iron ore", 5400), ("Coal", 5400), ("Stamina potion(4)", 9)], [("Steel bar", 5400)],
  quests=["The Giant Dwarf"], note="Below 60 Smithing the foreman fee is extra.")
m("Smelting mithril bars at Blast Furnace", "Smithing", {"Smithing": 50}, True,
  [("Coins", 72000), ("Mithril ore", 3600), ("Coal", 7200), ("Stamina potion(4)", 9)], [("Mithril bar", 3600)],
  quests=["The Giant Dwarf"], note="Assumes a coal bag.")
m("Smelting adamantite bars at Blast Furnace", "Smithing", {"Smithing": 70}, True,
  [("Coins", 72000), ("Adamantite ore", 2700), ("Coal", 8100), ("Stamina potion(4)", 9)], [("Adamantite bar", 2700)],
  quests=["The Giant Dwarf"])
m("Smelting runite bars at Blast Furnace", "Smithing", {"Smithing": 85}, True,
  [("Coins", 72000), ("Runite ore", 2160), ("Coal", 8640), ("Extended stamina potion(4)", 4)], [("Runite bar", 2160)],
  quests=["The Giant Dwarf"])

# ---------------------------------------------------------------- Sailing
m("Salvaging small shipwrecks", "Sailing", {"Sailing": 15}, True, [],
  [("Bronze bar", 16.32), ("Logs", 16.22), ("Bronze nails", 47.95), ("Oak logs", 8.25), ("Coins", 828), ("Plank", 8.23),
   ("Bronze cannonball", 24.62), ("Iron nails", 24.1), ("Water rune", 44.15), ("Air rune", 44.08),
   ("Iron cannonball", 12.44), ("Oak plank", 4.13), ("Iron bar", 4.02), ("Steel arrow", 4.92)],
  quests=["Pandemonium"])
m("Deep sea trawling for yellowfin", "Sailing", {"Fishing": 79, "Construction": 72}, True,
  [("Ice cooler", 90), ("Teak repair kit", 8), ("Fish offcuts", 40)],
  [("Raw yellowfin", 805), ("Raw halibut", 70), ("Raw bluefin", 17), ("Raw marlin", 8)],
  quests=["Pandemonium"], note="Needs a crewmate with Helmsmanship 3+.")
m("Deep sea trawling for bluefin", "Sailing", {"Sailing": 72, "Fishing": 87}, True,
  [("Ice cooler", 79.5), ("Fine fish offcuts", 40)], [("Raw bluefin", 720), ("Raw marlin", 75)],
  quests=["Pandemonium"], note="Needs a crewmate with Helmsmanship 3+.")
m("Deep sea trawling for marlin", "Sailing", {"Sailing": 78, "Fishing": 91, "Construction": 72}, True,
  [("Ice cooler", 72.5), ("Ironwood repair kit", 8), ("Fine fish offcuts", 65)], [("Raw marlin", 650), ("Raw bluefin", 75)],
  quests=["Pandemonium"], note="Needs a crewmate with Helmsmanship 3+.")
m("Deep sea trawling for halibut", "Sailing", {"Sailing": 84, "Fishing": 83, "Construction": 73}, True,
  [("Ice cooler", 85.5), ("Fine fish offcuts", 45)],
  [("Raw halibut", 755), ("Raw yellowfin", 75), ("Raw bluefin", 17), ("Raw marlin", 8)],
  quests=["Pandemonium"], note="Needs a crewmate with Helmsmanship 3+.")

# ---------------------------------------------------------------- Crafting
m("Crafting gold jewellery", "Crafting", {"Crafting": 6}, False, [("Gold bar", 1400)], [("Gold necklace", 1400)])
m("Spinning flax to bow strings", "Crafting", {"Crafting": 10}, True, [("Bale of flax", 80)], [("Bow string", 2000)],
  note="Rate assumes an upgraded bow string spool.")
m("Crafting drift nets", "Crafting", {"Crafting": 26}, True, [("Jute fibre", 2200)], [("Drift net", 1100)])
m("Crafting topaz jewellery", "Crafting", {"Crafting": 45}, True, [("Silver bar", 1200), ("Red topaz", 1200)],
  [("Topaz amulet (u)", 1200)])
m("Crafting diamond jewellery", "Crafting", {"Crafting": 56}, False, [("Gold bar", 1200), ("Diamond", 1200)],
  [("Diamond necklace", 1200)])
m("Making toy cats", "Crafting", {"Crafting": 85, "Construction": 42}, True,
  [("Coins", 62880), ("Clockwork", 576), ("Plank", 576)], [("Toy cat", 576)], note="Very slow to sell.")

# ---------------------------------------------------------------- Fletching
m("Fletching ogre arrow shafts", "Fletching", {"Fletching": 5}, True, [("Coins", 14400)], [("Ogre arrow shaft", 7200)],
  quests=["Zogre Flesh Eaters"])
m("Making adamant brutal arrows", "Fletching", {"Fletching": 62}, True,
  [("Flighted ogre arrow", 15000), ("Adamantite nails", 15000)], [("Adamant brutal", 15000)],
  quests=["Zogre Flesh Eaters"])
m("Fletching moonlight antler bolts", "Fletching", {"Fletching": 72}, True, [("Moonlight antelope antler", 1800)],
  [("Moonlight antler bolts", 21600)])
m("Fletching gem-tipped dragon bolts", "Fletching", {"Fletching": 84}, True,
  [("Ruby bolt tips", 27000), ("Dragon bolts", 27000)], [("Ruby dragon bolts", 27000)], note="Very high capital.")
m("Stringing magic longbows", "Fletching", {"Fletching": 85}, True,
  [("Magic longbow (u)", 2400), ("Bow string", 2400)], [("Magic longbow", 2400)])

# ---------------------------------------------------------------- Herblore
m("Making tarromin potions", "Herblore", {"Herblore": 12}, True, [("Tarromin", 4000), ("Vial of water", 4000)],
  [("Tarromin potion (unf)", 4000)], quests=["Druidic Ritual"])
m("Making harralander potions", "Herblore", {"Herblore": 22}, True, [("Harralander", 4000), ("Vial of water", 4000)],
  [("Harralander potion (unf)", 4000)], quests=["Druidic Ritual"])
m("Making ranarr potions", "Herblore", {"Herblore": 30}, True, [("Ranarr weed", 4000), ("Vial of water", 4000)],
  [("Ranarr potion (unf)", 4000)], quests=["Druidic Ritual"])
m("Making prayer potions", "Herblore", {"Herblore": 38}, True,
  [("Snape grass", 2250), ("Ranarr weed", 2500), ("Vial of water", 2500), ("Coins", 500000)],
  [("Prayer potion(4)", 1969)], quests=["Druidic Ritual"],
  note="Zahur's fees included. Alchemist's amulet charges not counted.")
m("Cleaning grimy cadantine", "Herblore", {"Herblore": 65}, True, [("Grimy cadantine", 5000)], [("Cadantine", 5000)],
  quests=["Druidic Ritual"])
m("Making sanfew serum(4)", "Herblore", {"Herblore": 65}, True,
  [("Nail beast nails", 250), ("Unicorn horn dust", 250), ("Super restore(4)", 250)], [("Sanfew serum(4)", 250)],
  quests=["Druidic Ritual", "Zogre Flesh Eaters"], note="Snake weed must be gathered yourself.")

# ---------------------------------------------------------------- Firemaking
m("Collecting ashes", "Firemaking", {"Firemaking": 30}, False, [("Maple logs", 1000)], [("Ashes", 1000)])
m("Making magic pyre logs", "Firemaking", {"Firemaking": 1}, True, [("Sacred oil(4)", 1400), ("Magic logs", 1400)],
  [("Magic pyre logs", 1400), ("Vial", 1400)], quests=["Shades of Mort'ton"], note="Sacred oil is in short supply.")
m("Making redwood pyre logs", "Firemaking", {"Firemaking": 1}, True, [("Sacred oil(4)", 1400), ("Redwood logs", 1400)],
  [("Redwood pyre logs", 1400), ("Vial", 1400)], quests=["Shades of Mort'ton"])

# ---------------------------------------------------------------- Runecraft
m("Crafting cosmic runes", "Runecraft", {"Runecraft": 59}, True,
  [("Pure essence", 2640), ("Astral rune", 5), ("Cosmic rune", 5)], [("Cosmic rune", 8976)],
  quests=["Lost City"], note="Rates assume double cosmics (59) and the Raiments of the Eye.")
m("Crafting blood runes", "Runecraft", {"Runecraft": 77}, True,
  [("Pure essence", 4620), ("Stamina potion(4)", 4), ("Blood essence", 2.31)], [("Blood rune", 10626)],
  quests=["Sins of the Father"])
m("Crafting astral runes", "Runecraft", {"Runecraft": 85}, True, [("Pure essence", 5016), ("Stamina potion(4)", 7.6)],
  [("Astral rune", 17054)], quests=["Lunar Diplomacy"], note="Lunar spellbook teleports.")
m("Crafting wrath runes", "Runecraft", {"Runecraft": 95}, True, [("Pure essence", 5280)], [("Wrath rune", 8448)],
  quests=["Dragon Slayer II"])
m("Crafting nature runes through the Abyss", "Runecraft", {"Runecraft": 44, "Mining": 21, "Hitpoints": 70}, True,
  [("Pure essence", 2970), ("Stamina potion(4)", 7.5), ("Monkfish", 10), ("Amulet of glory(6)", 9.17)],
  [("Nature rune", 4752), ("Amulet of glory", 9.17)], quests=["Enter the Abyss"])
m("Crafting death runes through the Abyss", "Runecraft", {"Runecraft": 65, "Mining": 21, "Hitpoints": 70}, True,
  [("Pure essence", 3350), ("Stamina potion(4)", 4), ("Monkfish", 10), ("Amulet of glory(6)", 8.33)],
  [("Death rune", 11390), ("Amulet of glory", 8.33)], quests=["Enter the Abyss", "Mourning's End Part II"])

# ---------------------------------------------------------------- Thieving
m("Pickpocketing master farmers", "Thieving", {"Thieving": 38}, True, [],
  [("Watermelon seed", 31.75), ("Snape grass seed", 23.08), ("Barley seed", 2167), ("Hammerstone seed", 1667),
   ("Asgarnian seed", 879), ("Jute seed", 1245), ("Yanillian seed", 582), ("Krandorian seed", 291),
   ("Wildblood seed", 84.51), ("Dwarf weed seed", 0.86), ("Lantadyme seed", 1.44), ("Cadantine seed", 2.02),
   ("Ranarr seed", 22.65), ("Toadflax seed", 13.54), ("Avantoe seed", 6.34), ("Kwuarm seed", 4.32),
   ("Snapdragon seed", 3.24), ("Torstol seed", 0.65)],
  note="Rates at 94 Thieving with Rogue equipment; much lower at 38.")
m("Pickpocketing Knights of Ardougne", "Thieving", {"Thieving": 55}, True, [("Jug of wine", 15)], [("Coins", 300000)],
  note="Medium Ardougne Diary recommended.")
m("Pickpocketing paladins", "Thieving", {"Thieving": 70, "Agility": 50}, True,
  [("Coins", 5000), ("Dodgy necklace", 8.28)], [("Coins", 183200), ("Chaos rune", 4580)],
  note="Rates at 99 Thieving; about 346k/hr at 70.")
m("Pickpocketing vyres", "Thieving", {"Thieving": 82, "Agility": 50}, True, [("Dodgy necklace", 6.04)],
  [("Blood shard", 0.29), ("Coins", 298759), ("Death rune", 175), ("Blood rune", 87.27), ("Blood pint", 65.45),
   ("Uncut ruby", 54.55), ("Diamond", 10.91), ("Cooked mystery meat", 10.91)], quests=["Sins of the Father"],
  note="Rates at 99 Thieving. Hard Ardougne Diary.")
m("Pickpocketing elves", "Thieving", {"Thieving": 85, "Agility": 50}, True, [("Dodgy necklace", 16.18)],
  [("Enhanced crystal teleport seed", 1.09), ("Coins", 289406), ("Death rune", 140), ("Nature rune", 131),
   ("Fire orb", 17.5), ("Diamond", 8.75), ("Gold ore", 8.75)], quests=["Song of the Elves"],
  note="Rates at 99 Thieving. Crystal shards not counted.")

# ---------------------------------------------------------------- Farming (per run)
m("Farming hemp", "Farming", {"Farming": 37}, True,
  [("Hemp seed", 15), ("Ultracompost", 2.5), ("Flax", 30), ("Teleport card", 1)], [("Hemp", 125)],
  per_run=True, note="One 5-patch run, about every 80 minutes.")
m("Farming ranarr weed", "Farming", {"Farming": 32, "Magic": 61}, True, [("Ranarr seed", 10), ("Ultracompost", 10)],
  [("Grimy ranarr weed", 88)], per_run=True, quests=["Ghosts Ahoy", "My Arm's Big Adventure", "Fairytale I - Growing Pains"],
  note="One 10-patch herb run, about every 90 minutes.")
m("Farming snapdragon", "Farming", {"Farming": 62, "Magic": 61}, True, [("Snapdragon seed", 10), ("Ultracompost", 10)],
  [("Grimy snapdragon", 88)], per_run=True, quests=["Ghosts Ahoy", "My Arm's Big Adventure", "Fairytale I - Growing Pains"],
  note="One 10-patch herb run, about every 90 minutes.")
m("Farming torstol", "Farming", {"Farming": 85, "Magic": 61}, True, [("Torstol seed", 10), ("Ultracompost", 10)],
  [("Grimy torstol", 88)], per_run=True, quests=["Ghosts Ahoy", "My Arm's Big Adventure", "Fairytale I - Growing Pains"],
  note="One 10-patch herb run, about every 90 minutes.")
