# Skill Profit Advisor

A RuneLite plugin that tells you **what to train for money** in every non-combat skill, based on your current levels and live Grand Exchange prices.

Open the sidebar panel (coin-stack icon) while logged in. It shows two things:

- **Best for you right now:** the most profitable methods you can do at your current levels.
- **By skill:** for each non-combat skill, the most profitable method at your level, and the next method a higher level unlocks if it would earn more (for example, *Next: Smelting adamantite bars at Blast Furnace at 70 (2.4M/hr)*).

Hover over a method to see its requirements, what it uses and makes per hour, and its cost, value and profit. Click a method to open its OSRS Wiki money-making guide.

## How it works

- **Levels:** the plugin reads your real (unboosted) level in every skill. It refreshes when you log in, gain a level or change worlds, and when you press **Refresh**.
- **Methods:** 82 methods taken from the OSRS Wiki money-making guides, across all 16 non-combat skills. Each method stores only its items in and items out **per hour**, exactly as the guide lists them. Farming runs are stored per run.
- **Profit:** recalculated from **live GE prices** each time the panel refreshes, using RuneLite's own price data (`ItemManager`). The plugin makes no network requests of its own. By default the 2% GE tax is taken off everything a method sells; you can turn this off.
- **Free-to-play or members:** members methods are hidden on free-to-play worlds. You can override this in the settings.
- **Quests:** each method's quests are checked. Unfinished quests are shown in orange, because many methods only need part of a quest. You can turn on hiding instead.
- **Combat requirements:** methods that need a combat level (Magic, Hitpoints, Prayer and so on) are hidden by default.

### Settings

| Setting | Default | What it does |
|---|---|---|
| Methods to show | Detect from world | Show free-to-play or members methods, or detect from your world |
| Allow combat requirements | Off | Also show methods that need Magic, Hitpoints, Prayer and so on |
| Only finished quests | Off | Hide methods whose quests you haven't finished |
| Include GE tax | On | Take the 2% sales tax (items 50 gp and over, capped at 5M) off outputs |
| Include farming runs | On | Show herb and hemp runs, as profit per run |
| Show money-losing methods | Off | Include methods that currently lose money |
| Best overall count | 5 | How many methods to list at the top |

## Limits (read these)

- The per-hour rates are the wiki guides' figures, and those often assume good gear, diaries or high levels. For example, master farmer and vyre pickpocketing rates are quoted at 94–99 Thieving. Your real rate may be lower; the hover text says when a rate assumes more than the minimum level.
- GE buy limits and thin markets are not modelled. Admiral pies and toy cats sell slowly.
- Achievement diaries, boat upgrades and some quest parts can't be checked. They are listed in each method's note.
- Untradeable outputs are valued at 0: crystal shards, anima-infused bark, marks of grace, unidentified minerals.
- No money-making guide trains Construction, so it shows *No money-making guide trains this skill*.
- The method list is a snapshot of the wiki taken on 2026-10-07. Prices are live; the rates are not.

## Building and running

You need Java 11 or newer and IntelliJ IDEA (or Gradle on its own).

```
./gradlew run          # starts a developer RuneLite client with the plugin loaded
```

To log in to the developer client with a Jagex account, follow
https://github.com/runelite/runelite/wiki/Using-Jagex-Accounts.

```
./gradlew test         # unit tests for the ranking logic (9 tests)
./gradlew shadowJar    # a runnable jar with the plugin built in
```

### What to test in-game

1. **Log in.** The panel should switch from "Log in to see advice" to the lists. "Loading prices..." may show for a few seconds first.
2. **Membership.** On a free-to-play world, only free-to-play methods should show (cooking anchovies and pizzas, smelting, gold and diamond jewellery, ashes, fishing). On a members world, everything you qualify for should show.
3. **Level-up.** Gain a level in a skill near a threshold, for example 30 Smithing. Its row should update without pressing Refresh.
4. **Quests.** A method whose quest you haven't finished shows *Needs: ...* in orange. Turn on **Only finished quests** and it should disappear.
5. **Clicks.** Clicking a method opens the right wiki guide. Hovering shows the inputs, outputs and profit.
6. **Settings.** Every setting should redraw the panel immediately.

## Updating the method data

`tools/methods.py` holds the method table (item names and quantities per hour, with each guide's URL). `tools/gen_data.py` regenerates `MethodData.java` from it. It maps item names to `net.runelite.api.gameval.ItemID` constants and quest names to `Quest` constants, and fails loudly on anything it can't match:

```
python3 tools/gen_data.py <runelite>/runelite-api/src/main/java/net/runelite/api/Quest.java \
    <runelite>/runelite-api/src/main/java/net/runelite/api/gameval/ItemID.java \
    src/main/java/com/skillprofit/MethodData.java
```

## Rules this plugin follows

These are Jagex's third-party client guidelines and the RuneLite Plugin Hub rules.

- It only reads information: skill levels, world type, quest states and item prices.
- It adds no menu entries, sends nothing to the server and injects no input.
- It doesn't use reflection, JNI or any third-party network access; prices come from RuneLite.
- It uses no combat or boss information.

## License

BSD 2-Clause. See `LICENSE`.
