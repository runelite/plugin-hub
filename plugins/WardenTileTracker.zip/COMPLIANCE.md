# RuneLite and Jagex Compliance Justification

✅ Informational-Only Overlay: Provides tile indicators based on visible in-game animations.
✅ No Automation: Plugin does not interact with the game state or perform any clicks or movements.
✅ In-Combat Only (Optional): Defaults to appearing only in combat but can be toggled via config.
✅ Configurable Options: All user-visible changes are toggleable through the config panel.
✅ Zero Network or External File Interactions: No external data sources are used.
✅ Performance Optimized: Efficient use of event listeners and overlays, with caching to prevent FPS drops.
✅ Open Source: Code is open and available for RuneLite review.
