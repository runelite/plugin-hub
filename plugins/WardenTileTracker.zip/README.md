# Warden Tile Tracker

**Warden Tile Tracker** is a RuneLite plugin designed for Tombs of Amascut (ToA) encounters, specifically during the Warden fight. 
It tracks safe tile indicators (Right, Left, Middle) based on Warden animation patterns and displays them in a clean overlay.

## Features
- Displays the most recent safe tile before each siphon phase
- Shows current siphon count (up to 4)
- Option to hide or show overlay outside of Warden fights
- Color-customizable text and tiles through plugin config
- FPS-optimized; only active during relevant encounters

## Compliance
- ✅ No automation or game interaction
- ✅ Only reads in-game visible NPC animations
- ✅ No prediction or unfair advantage mechanics
- ✅ Purely informational and visual UI assist
- ✅ Passes RuneLite Plugin Hub guidelines

## Configuration Options
- Show Safe Tile Letter (on/off)
- Show Siphon Count (on/off)
- Overlay Colors (Safe/Unsafe/Text/Border/Fill)
- Font Size and Overlay Box Size
- Option to Always Show Overlay (on/off)

## License
[MIT License](LICENSE)
